#!/bin/bash

if [ -f textile.xml ] ; then
    rm textile.xml
fi

source ./ROUTINES.cfg
source ./VARIABLES.cfg


	echo '<?xml version="1.0" encoding="UTF-8"?><wiki_page><title>Prevzem</title><parent title="Wiki"/><text>' >> textile.xml
	echo >> textile.xml

	sed s/___var_Station___/$var_Station/g <WIKI/tpl/PrevzDoc_01.tpl >> textile.xml
		item_zap "CGS" "APOA370" $var_ZK1_O3_ISMM_serial $var_PIVKA_PATH
		item_zap "CGS" "APNA370" $var_ZK1_NOx_ISMM_serial $var_PIVKA_PATH
		item_zap "CGS" "APSA370" $var_ZK1_SO2_ISMM_serial $var_PIVKA_PATH
		item_zap "CGS" "APMA370" $var_ZK1_CO_ISMM_serial $var_PIVKA_PATH
		item_zap "CGS" "APDA370" $var_ZK1_PM_ISMM_serial $var_PIVKA_PATH
		item_zap "CGS" "AE33" $var_ZK1_BC_ISMM_serial $var_PIVKA_PATH

	sed s/___var_Station___/$var_Station/g <WIKI/tpl/PrevzDoc_02.tpl >> textile.xml
		item_zap "VNET" "hmp155p" $var_ZK1_N3_P2_ISMM_serial $var_PIVKA_PATH
		item_zap "VNET" "hmp155p" $var_N2_P2_ISMM_serial $var_PIVKA_PATH
		item_zap "VNET" "seq47-50d" $var_ZK1_N3_P1_ISMM_serial $var_PIVKA_PATH
		item_zap "VNET" "uSonic3d" $var_ZK1_N3_P6_ISMM_serial $var_PIVKA_PATH
		item_zap "VNET" "uSonic3d" $var_N2_P1_ISMM_serial $var_PIVKA_PATH
		item_zap "VNET" "smp11" $var_ZK1_N3_P5_ISMM_serial $var_PIVKA_PATH

	sed s/___var_Station___/$var_Station/g <WIKI/tpl/PrevzDoc_03.tpl >> textile.xml
		item_zap "ELTRATEC" "mbIO120" $var_N2_P7_ISMM_serial  $var_PIVKA_PATH
	sed s/___var_Station___/$var_Station/g <WIKI/tpl/PrevzDoc_04.tpl >> textile.xml

	echo '</text></wiki_page>' >> textile.xml
	#FIND_Prevzem
	curl -v -u nkostic:Kosnik00 -H "Content-Type: application/xml" -X PUT http://pivka.arso.sigov.si/redmine/projects/$var_WIKI_PATH/wiki/Prevzem.xml --data-binary "@textile.xml"
	rm textile.xml	
