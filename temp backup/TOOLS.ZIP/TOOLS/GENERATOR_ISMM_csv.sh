#!/bin/bash

source ./ROUTINES.cfg
source ./VARIABLES.cfg


echo Path, Type,Manufacturer,Serial number,Certificate date,Certificate number

echo "PLOSCA", $cabinet_type, $cabinet_manufacturer, $cabinet_serial, $cabinet_certDate , $cabinet_certNum

echo "(N1)", $cabinet_N1_type, $cabinet_N1_manufacturer, $cabinet_N1_serial, "", ""
echo "(PS1/0)", $cabinet_PS1_0_type, $cabinet_PS1_0_manufacturer, $cabinet_PS1_0_serial, "", ""
echo "(PS2/0)", $cabinet_PS2_0_type, $cabinet_PS2_0_manufacturer, $cabinet_PS2_0_serial, "", ""
echo "(PS2/1)", $cabinet_PS2_1_type, $cabinet_PS2_1_manufacturer, $cabinet_PS2_1_serial, "", ""
echo "(PS3)", $cabinet_PS3_type, $cabinet_PS3_manufacturer, $cabinet_PS3_serial, "", ""
echo "(PS4)", $cabinet_PS4_type, $cabinet_PS4_manufacturer, $cabinet_PS4_serial, "", ""


echo "(ZK1->N3) - MOXA Nport-6650", $MoxaUC_type, $MoxaUC_manufacturer, $MoxaUC_serial, $MoxaUC_certDate, $MoxaUC_certNum
echo "(ZK1->N3)->port1", $var_ZK1_N3_P1_ISMM_device, $var_ZK1_N3_P1_ISMM_manufacturer, $var_ZK1_N3_P1_ISMM_serial, $var_ZK1_N3_P1_ISMM_certDate, $var_ZK1_N3_P1_ISMM_certNum
echo "(ZK1->N3)->port2", $var_ZK1_N3_P2_ISMM_device, $var_ZK1_N3_P2_ISMM_manufacturer, $var_ZK1_N3_P2_ISMM_serial, $var_ZK1_N3_P2_ISMM_certDate, $var_ZK1_N3_P2_ISMM_certNum
echo "(ZK1->N3)->port5", $var_ZK1_N3_P5_ISMM_device, $var_ZK1_N3_P5_ISMM_manufacturer, $var_ZK1_N3_P5_ISMM_serial, $var_ZK1_N3_P5_ISMM_certDate, $var_ZK1_N3_P5_ISMM_certNum
echo "(ZK1->N3)->port6", $var_ZK1_N3_P6_ISMM_device, $var_ZK1_N3_P6_ISMM_manufacturer, $var_ZK1_N3_P6_ISMM_serial, $var_ZK1_N3_P6_ISMM_certDate, $var_ZK1_N3_P6_ISMM_certNum

echo "(ZK1->O3)", $var_ZK1_O3_ISMM_device, $var_ZK1_O3_ISMM_manufacturer, $var_ZK1_O3_ISMM_serial, $var_ZK1_O3_ISMM_certDate, $var_ZK1_O3_ISMM_certNum
echo "(ZK1->NOx)", $var_ZK1_NOx_ISMM_device, $var_ZK1_NOx_ISMM_manufacturer, $var_ZK1_NOx_ISMM_serial, $var_ZK1_NOx_ISMM_certDate, $var_ZK1_NOx_ISMM_certNum
echo "(ZK1->SO2)", $var_ZK1_SO2_ISMM_device, $var_ZK1_SO2_ISMM_manufacturer, $var_ZK1_SO2_ISMM_serial, $var_ZK1_SO2_ISMM_certDate, $var_ZK1_SO2_ISMM_certNum
echo "(ZK1->CO)", $var_ZK1_CO_ISMM_device, $var_ZK1_CO_ISMM_manufacturer, $var_ZK1_CO_ISMM_serial, $var_ZK1_CO_ISMM_certDate, $var_ZK1_CO_ISMM_certNum
echo "(ZK1->PM)", $var_ZK1_PM_ISMM_device, $var_ZK1_PM_ISMM_manufacturer, $var_ZK1_PM_ISMM_serial, $var_ZK1_PM_ISMM_certDate, $var_ZK1_PM_ISMM_certNum
echo "(ZK1->BC)", $var_ZK1_BC_ISMM_device, $var_ZK1_BC_ISMM_manufacturer, $var_ZK1_BC_ISMM_serial, $var_ZK1_BC_ISMM_certDate, $var_ZK1_BC_ISMM_certNum

echo "(N2) - MOXA UC-8410A-T-LX", $MoxaUC_type, $MoxaUC_manufacturer, $MoxaUC_serial, $MoxaUC_certDate, $MoxaUC_certNum
echo "(N3)->port1", $var_N2_P1_ISMM_device, $var_N2_P1_ISMM_manufacturer, $var_N2_P1_ISMM_serial, $var_N2_P1_ISMM_certDate, $var_N2_P1_ISMM_certNum
echo "(N3)->port2", $var_N2_P2_ISMM_device, $var_N2_P2_ISMM_manufacturer, $var_N2_P2_ISMM_serial, $var_N2_P2_ISMM_certDate, $var_N2_P2_ISMM_certNum
echo "(N3)->port7", $var_N2_P7_ISMM_device, $var_N2_P7_ISMM_manufacturer, $var_N2_P7_ISMM_serial, $var_N2_P7_ISMM_certDate, $var_N2_P7_ISMM_certNum
