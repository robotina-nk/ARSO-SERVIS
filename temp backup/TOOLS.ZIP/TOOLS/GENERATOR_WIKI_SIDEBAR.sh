#!/bin/bash

if [ -f textile.xml ] ; then
    rm textile.xml
fi

source ./ROUTINES.cfg
source ./VARIABLES.cfg


	echo '<?xml version="1.0" encoding="UTF-8"?><wiki_page><title>Sidebar</title><parent title="Wiki"/><text>{{include(Projekt)}}</text></wiki_page>' >> textile.xml
	#FIND_Sidebar
		curl -v -u nkostic:Kosnik00 -H "Content-Type: application/xml" -X PUT http://pivka.arso.sigov.si/redmine/projects/$var_WIKI_PATH/wiki/Sidebar.xml --data-binary "@textile.xml"
	rm textile.xml
