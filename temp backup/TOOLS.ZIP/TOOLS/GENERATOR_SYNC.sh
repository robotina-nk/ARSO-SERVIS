#!/bin/bash

source ./ROUTINES.cfg
source ./VARIABLES.cfg

	sshpass -p "Kosnik00" rsync -avz --ignore-existing --exclude '.svn' TEMP/ROBOTINA/cc*.pdf TEMP/VNET/cc*.pdf TEMP/CGS/cc*.pdf TEMP/ELTRATEC/cc*.pdf nkostic@pivka.arso.sigov.si:/opt1/arso/docs/xober_op_location/4000_aoberl/$var_PIVKA_PATH/310_cc
#	sshpass -p "Kosnik00" rsync -avz --ignore-existing --exclude '.svn' TEMP/ROBOTINA/montaza*.pdf nkostic@pivka.arso.sigov.si:/opt1/arso/docs/xober_op_location/4000_aoberl/$var_PIVKA_PATH/800_prevzemi/100_testni_zagon/103_ustreznost_montaze
	sshpass -p "Kosnik00" rsync -avz --ignore-existing --exclude '.svn' TEMP/ROBOTINA/garancija*.pdf TEMP/VNET/garancija*.pdf TEMP/CGS/garancija*.pdf TEMP/ELTRATEC/garancija*.pdf nkostic@pivka.arso.sigov.si:/opt1/arso/docs/xober_op_location/4000_aoberl/$var_PIVKA_PATH/800_prevzemi/100_testni_zagon/102_garancije
	sshpass -p "Kosnik00" rsync -avz --ignore-existing --exclude '.svn' TEMP/VNET/*Prevzem*.pdf TEMP/CGS/*Prevzem*.pdf TEMP/ELTRATEC/*Prevzem*.pdf nkostic@pivka.arso.sigov.si:/opt1/arso/docs/xober_op_location/4000_aoberl/$var_PIVKA_PATH/800_prevzemi/200_zagon_lokacija

#rm -rf TEMP
