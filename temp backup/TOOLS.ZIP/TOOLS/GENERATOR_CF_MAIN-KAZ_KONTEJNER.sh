#!/bin/bash

source ./ROUTINES.cfg
source ./VARIABLES.cfg



# BEGIN (HEADER)
cat CF/tpl/begin.tpl >> result.htm

# uc8410A-LX & Nport5650-DT-J (STRIPE)
cat CF/tpl/table_devices.tpl >> result.htm

# headerSensors (STRIPE)
cat CF/tpl/headerSensors.tpl >> result.htm

sed s/___VAR1___/KAZ-KONTEJNER/g <CF/tpl/sens_emptyWlabel.tpl >> result.htm # KONTEJNER
# uc 8410A-LX
Col_sens_col0
Col_sens_col1 "uc8410A-LX" ""
Col_sens_col2 "images_files/uc8410A-LX.jpg"
Col_sens_col3 "N2-ioctl"
Col_sens_col4 "" "system_call_ioctl" "" "system_call_ioctl"  # DOESNT ACCEPT SPACE ???
Col_sens_col5 "N2_uc8410d/uc8410iod_ref.htm" "uc8410iod_ref.htm"
#Col_sens_col6_7_8
Col_sens_col6 "" ""
Col_sens_empty

Col_sens_template "uSonic3d" "3D\x20wind" "N3-1\x2Fip\x3A64001" "TODO" "TODO" $var_ZK1_64101_N3_P1_Port $var_ZK1_64101_N3_P1_serConfig "N3-8_usonic3d" "TODO_acdc" #SPACE escaped \x20->" ", \x3A->":", \x2F->"/"   
cat CF/tpl/sens_empty.tpl >> result.htm
Col_sens_template "hmp155" "T,\x20RH" "N3-2\x2Fip\x3A64002" "rs485_2w" "4800/7/even/1" $var_ZK1_64102_N3_P2_Port $var_ZK1_64102_N3_P2_serConfig "N5-2_hmp155d" "7-28Vdc"
cat CF/tpl/sens_empty.tpl >> result.htm
Col_sens_template "smp11" "W\x2Fm2\x20-\x20sun\x20radiation\x20global" "N3-5\x2Fip\x3A64005" "rs232_3w" "9600/8/none/1" $var_ZK1_64105_N3_P5_Port $var_ZK1_64105_N3_P5_serConfig "N5-5_smp11d" "4-15Vdc"
cat CF/tpl/sens_empty.tpl >> result.htm
Col_sens_template "seq47-50d" "leckeld" "N3-6\x2Fip\x3A64006" "TODO" "TODO" $var_ZK1_64106_N3_P6_Port $var_ZK1_64106_N3_P6_serConfig "N3-6_seq47-50d" "TODO_acdc"
cat CF/tpl/sens_empty.tpl >> result.htm
Col_sens_template "APOA370" "O3" "O3\x2Fip\x3A53700" "TODO" "TODO" "TODO" "TODO" "O3_apoa370d" "TODO_acdc"
cat CF/tpl/sens_empty.tpl >> result.htm
Col_sens_template "APNA370" "NoX" "NoX\x2Fip\x3A53700" "TODO" "TODO" "TODO" "TODO" "NOx_apna370d" "TODO_acdc"
cat CF/tpl/sens_empty.tpl >> result.htm
Col_sens_template "APSA370" "SO2" "SO2\x2Fip\x3A53700" "TODO" "TODO" "TODO" "TODO" "SO2_apsa370d" "TODO_acdc"
cat CF/tpl/sens_empty.tpl >> result.htm
Col_sens_template "APMA370" "CO" "CO\x2Fip\x3A53700" "TODO" "TODO" "TODO" "TODO" "CO_apma370d" "TODO_acdc"
cat CF/tpl/sens_empty.tpl >> result.htm
Col_sens_template "APDA370" "PM" "PM\x2Fip\x3A53700" "TODO" "TODO" "TODO" "TODO" "PM_apda372d" "TODO_acdc"
cat CF/tpl/sens_empty.tpl >> result.htm
Col_sens_template "AE33" "BC" "BC\x2Fip\x3A53700" "TODO" "TODO" "TODO" "TODO" "BC_ae33d" "TODO_acdc"
cat CF/tpl/sens_empty.tpl >> result.htm
Col_sens_template "mbIO" "T,\x20RH,\x20status-vrat" "TODO" "TODO" "TODO" "TODO" "TODO" "N4-1_mbIO120d" "7-28Vdc"
cat CF/tpl/sens_empty.tpl >> result.htm
Col_sens_template "iod" "dT" "TODO" "TODO" "TODO" "TODO" "TODO" "FOLDER" "TODO_acdc"
cat CF/tpl/sens_empty.tpl >> result.htm
cat CF/tpl/sens_empty.tpl >> result.htm





# CLOSING
cat result.htm | sed s/_data// > result01.htm
	sed s/___Station_location_code___/$var_Station_location_code/ <result01.htm >result02.htm
	sed s/___N2_eth0___/$var_N2_eth0/ <result02.htm >result03.htm
	sed s/___N3_eth0___/$var_N3_eth0/ <result03.htm >result04.htm
	sed s/___N4_eth0___/$var_N4_eth0/ <result04.htm >result05.htm
	sed s/___ME102_eth0___/$var_ME102_eth0/ <result05.htm >result06.htm
	sed s/___ME113_eth0___/$var_ME113_eth0/ <result06.htm >result07.htm
	sed s/___BR302_eth0___/$var_BR302_eth0/ <result07.htm >result08.htm
	sed s/___BR313_eth0___/$var_BR313_eth0/ <result08.htm >result09.htm
	sed s/___BR121_eth0___/$var_BR121_eth0/ <result09.htm >result10.htm
	sed s/___BR122_eth0___/$var_BR122_eth0/ <result10.htm >result11.htm
	sed s/___K01_eth0___/$var_K01_eth0/ <result11.htm >result12.htm
	sed s/___MK1_eth0___/$var_MK1_eth0/ <result12.htm >4000_KAZ_ref.htm


rm result*.htm
mv 4000_KAZ_ref.htm ../
