#!/bin/bash

if [ -f textile.xml ] ; then
    rm textile.xml
fi

source ./ROUTINES.cfg
source ./VARIABLES.cfg


	echo '<?xml version="1.0" encoding="UTF-8"?><wiki_page><title>Garancija</title><parent title="Wiki"/><text>' >> textile.xml
	echo >> textile.xml
	echo "h1. Garancijske izjave" >> textile.xml
	echo "" >> textile.xml
	echo "----" >> textile.xml
	echo "" >> textile.xml
	echo "h2. Senzorika" >> textile.xml
	echo "" >> textile.xml
	echo "----" >> textile.xml
	echo "" >> textile.xml
	echo "" >> textile.xml
	echo "h3. Vaisala" >> textile.xml
	echo "" >> textile.xml
	item_gar $var_ZK1_N3_P2_ISMM_serial $var_PIVKA_PATH "hmp155p" "VNET" #OK
	item_gar $var_N2_P2_ISMM_serial $var_PIVKA_PATH "hmp155p" "VNET" #OK
	echo "" >> textile.xml
	echo "h3. Metek" >> textile.xml
	echo "" >> textile.xml
	item_gar $var_ZK1_N3_P1_ISMM_serial $var_PIVKA_PATH "seq47-50d" "VNET" #OK
	echo "" >> textile.xml
	echo "h3. Leckel" >> textile.xml
	echo "" >> textile.xml
	item_gar $var_ZK1_N3_P6_ISMM_serial $var_PIVKA_PATH "uSonic3d" "VNET" #OK
	item_gar $var_N2_P1_ISMM_serial $var_PIVKA_PATH "uSonic3d" "VNET" #OK
	echo "" >> textile.xml
	echo "h3. Kipp&Zonen" >> textile.xml
	echo "" >> textile.xml
	item_gar $var_ZK1_N3_P5_ISMM_serial $var_PIVKA_PATH "smp11" "VNET" #OK
	echo "" >> textile.xml
	echo "h3. Horiba" >> textile.xml
	echo "" >> textile.xml
	item_gar $var_ZK1_O3_ISMM_serial $var_PIVKA_PATH "APOA370" "CGS" #OK
	item_gar $var_ZK1_NOx_ISMM_serial $var_PIVKA_PATH "APNA370" "CGS" #OK
	item_gar $var_ZK1_SO2_ISMM_serial $var_PIVKA_PATH "APSA370" "CGS" #OK
	item_gar $var_ZK1_CO_ISMM_serial $var_PIVKA_PATH "APMA370" "CGS" #OK
	item_gar $var_ZK1_PM_ISMM_serial $var_PIVKA_PATH "APDA370" "CGS" #OK
	item_gar $var_ZK1_BC_ISMM_serial $var_PIVKA_PATH "AE33" "CGS" #OK
	echo "" >> textile.xml
	echo "h3. Eltratec" >> textile.xml
	echo "" >> textile.xml
	item_gar $var_N2_P7_ISMM_serial $var_PIVKA_PATH "mbIO120" "ELTRATEC"
	echo "" >> textile.xml



	echo '</text></wiki_page>' >> textile.xml
	#FIND_Garancija
	curl -v -u nkostic:Kosnik00 -H "Content-Type: application/xml" -X PUT http://pivka.arso.sigov.si/redmine/projects/$var_WIKI_PATH/wiki/Garancija.xml --data-binary "@textile.xml"
	rm textile.xml	
