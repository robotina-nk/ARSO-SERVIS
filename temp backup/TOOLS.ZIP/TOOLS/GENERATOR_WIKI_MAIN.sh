#!/bin/bash

if [ -f textile.xml ] ; then
    rm textile.xml
fi

source ./ROUTINES.cfg
source ./VARIABLES.cfg

#var_WIKI_PATH="e4000_test_wiki-testna-postaja"



	echo '<?xml version="1.0" encoding="UTF-8"?><wiki_page><title>Wiki</title><text>h1. '$var_Station >> textile.xml
	cat WIKI/tpl/Wiki_01.tpl >> textile.xml

	echo "h2. Merilna postaja" >> textile.xml
	echo "" >> textile.xml
	echo "{background:#dddddd}. |_\2=.Lokacija||_\2=.Merilni sistem|" >> textile.xml
	echo "|_&lt;.Ime lokacije|%{background:lightgreen}$var_Station_name%||_&lt;.Proizvajalec|%{background:lightgreen}$var_Station_Manufacturer%|" >> textile.xml
	echo "|_&lt;.Koda lokacije|%{background:lightgreen}$var_Station_location_code%||_&lt;.Tip|%{background:lightgreen}$var_Station_type%|" >> textile.xml
	echo "|_&lt;.Koda postaje|%{background:lightgreen}$var_Station_code%||_&lt;.Serijska številka|%{background:lightgreen}$var_Station_Sn%|" >> textile.xml
	echo "|_&lt;.Gx|%{background:lightgreen}$var_Station_Gx%||||" >> textile.xml
	echo "|_&lt;.Gy|%{background:lightgreen}$var_Station_Gy%||||" >> textile.xml
	echo "|_&lt;.Gz|%{background:lightgreen}$var_Station_Gz%||||" >> textile.xml
	echo "" >> textile.xml
	echo "{background:#dddddd}. |_\5=. Komunikacijske nastavitve|" >> textile.xml
	echo "|_&lt;.Tip | ADSL/MPLS ||" >> textile.xml
	echo "|_&lt;.DNS name|%{background:lightgreen}$var_DNSname%||" >> textile.xml
	echo "|_&lt;.DNS|%{background:lightgreen}$var_DNS%||" >> textile.xml
	echo "|_&lt;.netmask|%{background:lightgreen}$var_mask%||" >> textile.xml
	echo "|_&lt;.broadcast|%{background:lightgreen}$var_bcast%||" >> textile.xml
	echo "|_&lt;.network|%{background:lightgreen}$var_network%||" >> textile.xml
	echo "|_&lt;.gateway|%{background:lightgreen}$var_gw%||" >> textile.xml
	echo "" >> textile.xml

	echo ". |_\5=. Servers_KAZ-KONTEJNER|" >> textile.xml  ##################################################### Servers_KAZ-KONTEJNER
	ser_Serv $var_ZK1_N3_Tip "www.moxa.com" $var_ZK1_N3_Host "N3" $var_ZK1_N3_Name $var_ZK1_N3_Location $var_ZK1_N3_eth0 "\${var_ZK1_N3_account_user_pass_X}" "\${var_ZK1_N3_account_protocol}"
		echo "|||sensord ip:port|Serial Server ip:port|Communication interface|" >> textile.xml
			echo "||%{background:lightgreen}$var_ZK1_64101_proc%|%{background:lightgreen}$var_ZK1_64101_IP":"64101%|%{background:lightgreen}$var_ZK1_N3_eth0":"64001%|%{background:lightgreen}$var_ZK1_64101_N3_P1_Port - $var_ZK1_64101_N3_P1_serConfig%|" >> textile.xml 
			echo "||%{background:lightgreen}$var_ZK1_64102_proc%|%{background:lightgreen}$var_ZK1_64102_IP":"64102%|%{background:lightgreen}$var_ZK1_N3_eth0":"64002%|%{background:lightgreen}$var_ZK1_64102_N3_P2_Port - $var_ZK1_64102_N3_P2_serConfig%|" >> textile.xml 
			echo "||%{background:lightgreen}$var_ZK1_64105_proc%|%{background:lightgreen}$var_ZK1_64105_IP":"64105%|%{background:lightgreen}$var_ZK1_N3_eth0":"64005%|%{background:lightgreen}$var_ZK1_64105_N3_P5_Port - $var_ZK1_64105_N3_P5_serConfig%|" >> textile.xml 
			echo "||%{background:lightgreen}$var_ZK1_64106_proc%|%{background:lightgreen}$var_ZK1_64106_IP":"64106%|%{background:lightgreen}$var_ZK1_N3_eth0":"64006%|%{background:lightgreen}$var_ZK1_64106_N3_P6_Port - $var_ZK1_64106_N3_P6_serConfig%|" >> textile.xml 

	ser_Serv $var_ZK1_O3_Tip "www.horiba.com" $var_ZK1_O3_Host "O3" $var_ZK1_O3_Name $var_ZK1_O3_Location $var_ZK1_O3_eth0 "\${var_ZK1_O3_account_user_pass_X}" "\${var_ZK1_O3_account_protocol}"
		echo "|||sensord ip:port|Serial Server ip:port|Communication interface|" >> textile.xml
			echo "||%{background:lightgreen}$var_ZK1_64001_proc%|%{background:lightgreen}$var_ZK1_64001_IP":"64001%|%{background:lightgreen}$var_ZK1_O3_eth0":"53700%|%{background:lightgreen}TODO%|" >> textile.xml 

	ser_Serv $var_ZK1_NOx_Tip "www.horiba.com" $var_ZK1_NOx_Host "NOx" $var_ZK1_NOx_Name $var_ZK1_NOx_Location $var_ZK1_NOx_eth0 "\${var_ZK1_NOx_account_user_pass_X}" "\${var_ZK1_NOx_account_protocol}"
		echo "|||sensord ip:port|Serial Server ip:port|Communication interface|" >> textile.xml
			echo "||%{background:lightgreen}$var_ZK1_64002_proc%|%{background:lightgreen}$var_ZK1_64001_IP":"64002%|%{background:lightgreen}$var_ZK1_NOx_eth0":"53700%|%{background:lightgreen}TODO%|" >> textile.xml 

	ser_Serv $var_ZK1_SO2_Tip "www.horiba.com" $var_ZK1_SO2_Host "SO2" $var_ZK1_SO2_Name $var_ZK1_SO2_Location $var_ZK1_SO2_eth0 "\${var_ZK1_SO2_account_user_pass_X}" "\${var_ZK1_SO2_account_protocol}"
		echo "|||sensord ip:port|Serial Server ip:port|Communication interface|" >> textile.xml
			echo "||%{background:lightgreen}$var_ZK1_64003_proc%|%{background:lightgreen}$var_ZK1_64001_IP":"64003%|%{background:lightgreen}$var_ZK1_SO2_eth0":"53700%|%{background:lightgreen}TODO%|" >> textile.xml 

	ser_Serv $var_ZK1_CO_Tip "www.horiba.com" $var_ZK1_CO_Host "CO" $var_ZK1_CO_Name $var_ZK1_CO_Location $var_ZK1_CO_eth0 "\${var_ZK1_CO_account_user_pass_X}" "\${var_ZK1_CO_account_protocol}"
		echo "|||sensord ip:port|Serial Server ip:port|Communication interface|" >> textile.xml
			echo "||%{background:lightgreen}$var_ZK1_64004_proc%|%{background:lightgreen}$var_ZK1_64001_IP":"64004%|%{background:lightgreen}$var_ZK1_CO_eth0":"53700%|%{background:lightgreen}TODO%|" >> textile.xml 

	ser_Serv $var_ZK1_PM_Tip "www.horiba.com" $var_ZK1_PM_Host "PM" $var_ZK1_PM_Name $var_ZK1_PM_Location $var_ZK1_PM_eth0 "\${var_ZK1_PM_account_user_pass_X}" "\${var_ZK1_PM_account_protocol}"
		echo "|||sensord ip:port|Serial Server ip:port|Communication interface|" >> textile.xml
			echo "||%{background:lightgreen}$var_ZK1_64005_proc%|%{background:lightgreen}$var_ZK1_64001_IP":"64005%|%{background:lightgreen}$var_ZK1_PM_eth0":"53700%|%{background:lightgreen}TODO%|" >> textile.xml 

	ser_Serv $var_ZK1_BC_Tip "www.horiba.com" $var_ZK1_BC_Host "BC" $var_ZK1_BC_Name $var_ZK1_BC_Location $var_ZK1_BC_eth0 "\${var_ZK1_BC_account_user_pass_X}" "\${var_ZK1_BC_account_protocol}"
		echo "|||sensord ip:port|Serial Server ip:port|Communication interface|" >> textile.xml
			echo "||%{background:lightgreen}$var_ZK1_64006_proc%|%{background:lightgreen}$var_ZK1_64001_IP":"64006%|%{background:lightgreen}$var_ZK1_BC_eth0":"53700%|%{background:lightgreen}TODO%|" >> textile.xml 


	cat WIKI/tpl/Wiki_02.tpl >> textile.xml
	echo "* *URL:* http://kolomon.arso.sigov.si/ismm/SVRMM/xober_oprema_mreza.php?koda="$var_Station_code >> textile.xml
	cat WIKI/tpl/Wiki_03.tpl >> textile.xml
	#cat tpl/Wiki_04_EDIT_AktualnaVerzijaProgramskeOpreme.tpl >> textile.xml
	#	cat DEL_AktualnaVerzijaProgramskeOpreme.txt >> textile.xml
	#cat tpl/Wiki_05_EDIT_IPKGrelease.tpl >> textile.xml
	#	cat DEL_IPKGRelease.txt >> textile.xml
	cat WIKI/tpl/Wiki_06.tpl >> textile.xml
	#cat tpl/Wiki_07_EDIT_ArhivVerzij.tpl >> textile.xml
	#	cat DEL_ArhivVerzij.txt >> textile.xml
	cat WIKI/tpl/Wiki_08.tpl >> textile.xml
	#cat tpl/Wiki_09_EDIT_SVNrepositorij.tpl >> textile.xml
	#	cat DEL_SVNRepozitorij.txt >> textile.xml
	cat WIKI/tpl/Wiki_10.tpl >> textile.xml
	#cat tpl/Wiki_11_EDIT_TehnicnaCFdokumentacija.tpl >> textile.xml
	#	cat DEL_TehnicnaCFdokumentacija.txt >> textile.xml
	cat WIKI/tpl/Wiki_12.tpl >> textile.xml
	echo '</text></wiki_page>' >> textile.xml

	#echo '</text></wiki_page>' >> textile.xml




		curl -v -u nkostic:Kosnik00 -H "Content-Type: application/xml" -X PUT http://pivka.arso.sigov.si/redmine/projects/$var_WIKI_PATH/wiki/Wiki.xml --data-binary "@textile.xml"
		#cat textile.xml > DEL.xml
	
