#!/bin/bash

#source ./ROUTINES.cfg
#source ./VARIABLES.cfg

# BEGIN (HEADER)
cat CF/sensors_tpl/beginning.tpl > $1d_ref.htm
	sed s/___SENSOR___/$1/g <$1d_ref.htm >result.htm
		mv result.htm $1d_ref.htm

# headerSensors (STRIPE)
#cat CF/tpl/headerSensors.tpl >> result.htm

#sed s/___VAR1___/KAZ-KONTEJNER/g <CF/tpl/sens_emptyWlabel.tpl >> result.htm # KONTEJNER


# HEADER
cat CF/sensors_tpl/headerTable.tpl >> $1d_ref.htm

# SENSOR
cat CF/sensors_tpl/sensorTableSTART.tpl >> $1d_ref.htm
cat CF/sensors_tpl/sensorTable01_01_$1.tpl >> $1d_ref.htm
cat CF/sensors_tpl/sensorTable01_02.tpl >> $1d_ref.htm
	sed s/___PORT___/$2/g <$1d_ref.htm >result.htm
		mv result.htm $1d_ref.htm
	sed s/___CHANNEL___/$3/g <$1d_ref.htm >result.htm
		mv result.htm $1d_ref.htm
	sed s/___SENSOR___/$1/g <$1d_ref.htm >result.htm
		mv result.htm $1d_ref.htm
cat CF/sensors_tpl/sensorTable01_03_$1.tpl >> $1d_ref.htm
cat CF/sensors_tpl/sensorTable01_04.tpl >> $1d_ref.htm
	sed s/___SENSOR___/$1/g <$1d_ref.htm >result.htm
		mv result.htm $1d_ref.htm
cat CF/sensors_tpl/sensorTable02_01_$1.tpl >> $1d_ref.htm
cat CF/sensors_tpl/sensorTable02_02.tpl >> $1d_ref.htm
	sed s/___SENSOR___/$1/g <$1d_ref.htm >result.htm
		mv result.htm $1d_ref.htm
cat CF/sensors_tpl/sensorTable03_01.tpl >> $1d_ref.htm
	sed s/___SENSOR___/$1/g <$1d_ref.htm >result.htm
		mv result.htm $1d_ref.htm
cat CF/sensors_tpl/sensorTable03_02_$1.tpl >> $1d_ref.htm




# CLOSING
#cat result.htm | sed s/_data// > result01.htm
#	sed s/___Station_location_code___/$var_Station_location_code/ <result01.htm >result02.htm
#	sed s/___N2_eth0___/$var_N2_eth0/ <result02.htm >result03.htm
#	sed s/___N3_eth0___/$var_N3_eth0/ <result03.htm >result04.htm
#	sed s/___N4_eth0___/$var_N4_eth0/ <result04.htm >result05.htm
#	sed s/___ME102_eth0___/$var_ME102_eth0/ <result05.htm >result06.htm
#	sed s/___ME113_eth0___/$var_ME113_eth0/ <result06.htm >result07.htm
#	sed s/___BR302_eth0___/$var_BR302_eth0/ <result07.htm >result08.htm
#	sed s/___BR313_eth0___/$var_BR313_eth0/ <result08.htm >result09.htm
#	sed s/___BR121_eth0___/$var_BR121_eth0/ <result09.htm >result10.htm
#	sed s/___BR122_eth0___/$var_BR122_eth0/ <result10.htm >result11.htm
#	sed s/___K01_eth0___/$var_K01_eth0/ <result11.htm >result12.htm
#	sed s/___MK1_eth0___/$var_MK1_eth0/ <result12.htm >4000_ref.htm


# CLOSING
cat CF/sensors_tpl/closing.tpl >> $1d_ref.htm

#rm result*.htm
#mv 4000_ref.htm ../

mv $1d_ref.htm ../$2_$1d/
