#!/bin/bash

source ./ROUTINES.cfg
source ./VARIABLES.cfg



# BEGIN (HEADER)
cat CF/tpl/begin.tpl >> result.htm

# uc8410A-LX & Nport5650-DT-J (STRIPE)
cat CF/tpl/table_devices.tpl >> result.htm

# headerSensors (STRIPE)
cat CF/tpl/headerSensors.tpl >> result.htm

#sed s/___VAR1___/KAZ-KONTEJNER/g <CF/tpl/sens_emptyWlabel.tpl >> result.htm # KONTEJNER
# uc 8410A-LX
Col_sens_col0
Col_sens_col1 "uc8410A-LX" ""
Col_sens_col2 "images_files/uc8410A-LX.jpg"
Col_sens_col3 "N2-ioctl"
Col_sens_col4 "" "system_call_ioctl" "" "system_call_ioctl"  # DOESNT ACCEPT SPACE ???
Col_sens_col5 "N2_uc8410d/uc8410iod_ref.htm" "uc8410iod_ref.htm"
#Col_sens_col6_7_8
Col_sens_col6 "" ""
Col_sens_empty



sed s/___VAR1___/KAZ-miniKONTEJNER/g <CF/tpl/sens_emptyWlabel.tpl >> result.htm # miniKONTEJNER

Col_sens_template "uSonic3d" "3D\x20wind" "N2-1\x2FttyM0" "TODO" "TODO" $var_N2_P1_Port $var_N2_P1_serConfig "TODO" "TODO_acdc" 
cat CF/tpl/sens_empty.tpl >> result.htm
Col_sens_template "hmp155" "T,\x20RH" "N2-2\x2FttyM1" "TODO" "TODO" $var_N2_P2_Port $var_N2_P2_serConfig "TODO" "TODO_acdc" 
cat CF/tpl/sens_empty.tpl >> result.htm
Col_sens_template "pluvio2" "Precipitation\x20sensor" "N2-4\x2FttyM3" "TODO" "TODO" $var_N2_P4_Port $var_N2_P4_serConfig "TODO" "TODO_acdc" 
cat CF/tpl/sens_empty.tpl >> result.htm
Col_sens_template "mbIO" "T,\x20RH,\x20status-vrat" "N2-5\x2FttyM4" "TODO" "TODO" $var_N2_P5_Port $var_N2_P5_serConfig "TODO" "TODO_acdc" 
cat CF/tpl/sens_empty.tpl >> result.htm






# CLOSING
cat result.htm | sed s/_data// > result01.htm
	sed s/___Station_location_code___/$var_Station_location_code/ <result01.htm >result02.htm
	sed s/___N2_eth0___/$var_N2_eth0/ <result02.htm >result03.htm
	sed s/___N3_eth0___/$var_N3_eth0/ <result03.htm >result04.htm
	sed s/___N4_eth0___/$var_N4_eth0/ <result04.htm >result05.htm
	sed s/___ME102_eth0___/$var_ME102_eth0/ <result05.htm >result06.htm
	sed s/___ME113_eth0___/$var_ME113_eth0/ <result06.htm >result07.htm
	sed s/___BR302_eth0___/$var_BR302_eth0/ <result07.htm >result08.htm
	sed s/___BR313_eth0___/$var_BR313_eth0/ <result08.htm >result09.htm
	sed s/___BR121_eth0___/$var_BR121_eth0/ <result09.htm >result10.htm
	sed s/___BR122_eth0___/$var_BR122_eth0/ <result10.htm >result11.htm
	sed s/___K01_eth0___/$var_K01_eth0/ <result11.htm >result12.htm
	sed s/___MK1_eth0___/$var_MK1_eth0/ <result12.htm >4000_KAZmini_ref.htm


rm result*.htm
mv 4000_KAZmini_ref.htm ../
