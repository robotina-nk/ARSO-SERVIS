#!/bin/bash
curl http://kolomon.arso.sigov.si/ismm/AMP/presta.php > presta.html
#sudo service ntp stop
#sudo ntpdate si.pool.ntp.org
#sudo service ntp start



d=`date -d '+6 hour' +%y%m%d%H%M%S`

cp ./presta.html oldprestas/presta_$d.html
./presta.sh presta.html | tee mail.txt
#sleep 120
echo "Presta pregled $d" | mutt -s "presta $d" nikola.kostic@robotina.com -a mail.txt header.xml presta.html
#echo "Presta pregled $d" | mutt -s "presta $d" nikola.kostic@robotina.com marko.mlakar@robotina.com -a mail.txt header.xml
mv mail.txt presta_$d.txt
rm mail.txt

#sshpass -p "Kosnik00" rsync -avz --ignore-existing --exclude '.svn' TEMP/ROBOTINA/cc*.pdf TEMP/VNET/cc*.pdf TEMP/CGS/cc*.pdf TEMP/ELTRATEC/cc*.pdf nkostic@pivka.arso.sigov.si:/opt1/arso/docs/xober_op_location/3000_moberl/$var_PIVKA_PATH/310_cc
sshpass -p "Kosnik00" rsync -avz presta_$d.txt nkostic@pivka.arso.sigov.si:/opt1/arso/docs/xober_op_location/0000_xoberl/000_korespondenca/Pregled_Presta_NetScan

rm presta_$d.txt
rm presta.html
rm heager.xml
