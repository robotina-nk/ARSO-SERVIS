#!/bin/bash
#curl http://kolomon.arso.sigov.si/ismm/AMP/presta.php > $var_presta
#curl http://kolomon.arso.sigov.si/ismm/AMP/presta.php > presta.html


#curl -i -H "Accept: application/xml" -H "Content-Type: application/xml" -X GET -u nkostic:Kosnik00 http://pivka.arso.sigov.si/redmine/projects/amws_location_00815_M450_Pavlicevo_sedlo/wiki/Wiki.xml > textile.xml

#curl -i -H "Accept: application/xml" -H "Content-Type: application/xml" -X GET -u nkostic:Kosnik00 http://pivka.arso.sigov.si/redmine/projects/asws_location_$1/wiki/Wiki.xml > $1.xml
#curl -i -H "Accept: application/xml" -H "Content-Type: application/xml" -X GET -u nkostic:Kosnik00 http://pivka.arso.sigov.si/redmine/projects/agws_location_$1/wiki/Wiki.xml > $1.xml
#curl -i -H "Accept: application/xml" -H "Content-Type: application/xml" -X GET -u nkostic:Kosnik00 http://pivka.arso.sigov.si/redmine/projects/amws_location_$1/wiki/Wiki.xml > $1.xml



var_pingStatus=-1
pingme(){
	ping -c 4 $1 >pinglog.txt #2>/dev/null 1>/dev/null #count 4, discard stderr in stdout
	var_pingStatus=$? #get a return value of a ping
#		echo var_pingStatus: $var_pingStatus
	if [[ var_pingStatus -eq 0 ]];then
		echo "Host found"
		cat pinglog.txt | grep "packets transmitted"
	else
		echo "!!!!! Host not found !!!!!"
		cat pinglog.txt | grep "packets transmitted"
		
		if grep -Fq "Time to live exceeded" pinglog.txt
		then
			echo "TTL expired in transit."
		else
			echo "Request timed out."
		fi
		
	fi
	rm pinglog.txt
}


fetchme_230(){
	echo $1 | sed 's/textileWiki\///g'
	var_Tip=$(cat $1 | grep Tip | head -1 | sed 's/^.*Tip|//' | sed 's/|//g')
	var_GW=$(cat $1 | grep gateway | sed 's/||||//g' | sed 's/|_&lt;.gateway|//g')
	var_IP1=$(cat $1 | grep IP1 | sed 's/|_&lt;.IP1|//g' | sed 's/||_&lt;.IP radius server||//g')
	echo var_Tip: $var_Tip
	echo var_GW: $var_GW
		pingme $var_GW
			echo
	echo var_IP1: $var_IP1
		pingme $var_IP1
			echo
}


fetchme_230_1Cam(){
	echo $1 | sed 's/textileWiki\///g'
	var_Tip=$(cat $1 | grep Tip | head -1 | sed 's/^.*Tip|//' | sed 's/|//g')
	var_GW=$(cat $1 | grep gateway | sed 's/||||//g' | sed 's/|_&lt;.gateway|//g')
	var_IP1=$(cat $1 | grep IP1 | sed 's/|_&lt;.IP1|//g' | sed 's/||_&lt;.IP radius server||//g')
	var_IPCam1=$(cat $1 | grep IPCam1 | sed 's/^.*IPCam1 IP|//' | sed 's/|//g')
	echo var_Tip: $var_Tip
	echo var_GW: $var_GW
		pingme $var_GW
			echo
	echo var_IP1: $var_IP1
		pingme $var_IP1
			echo
	echo var_IPCam1: $var_IPCam1
		pingme $var_IPCam1
			echo
}


fetchme_230_1ComSrv_1Cam(){
	echo $1 | sed 's/textileWiki\///g'
	var_Tip=$(cat $1 | grep Tip | head -1 | sed 's/^.*Tip|//' | sed 's/|//g')
	var_GW=$(cat $1 | grep gateway | sed 's/||||//g' | sed 's/|_&lt;.gateway|//g')
	var_IP1=$(cat $1 | grep IP1 | sed 's/|_&lt;.IP1|//g' | sed 's/||_&lt;.IP radius server||//g')
	var_ComServer1=$(cat $1 | grep ComServer1 | sed 's/\IPCam1 IP.*/IPCam1 IP/' | sed 's/||_&lt;.IPCam1 IP//g' | sed 's/|_&lt;.ComServer1 IP|//g')
	var_IPCam1=$(cat $1 | grep IPCam1 | sed 's/^.*IPCam1 IP|//' | sed 's/|//g')
	echo var_Tip: $var_Tip
	echo var_GW: $var_GW
		pingme $var_GW
			echo
	echo var_IP1: $var_IP1
		pingme $var_IP1
			echo
	echo var_ComServer1: $var_ComServer1
		pingme $var_ComServer1
			echo
	echo var_IPCam1: $var_IPCam1
		pingme $var_IPCam1
			echo
}


fetchme_230_1Cam_Solitax(){
	echo $1 | sed 's/textileWiki\///g'
	var_Tip=$(cat $1 | grep Tip | head -1 | sed 's/^.*Tip|//' | sed 's/|//g')
	var_GW=$(cat $1 | grep gateway | sed 's/||||//g' | sed 's/|_&lt;.gateway|//g')
	var_IP1=$(cat $1 | grep IP1 | sed 's/|_&lt;.IP1|//g' | sed 's/||_&lt;.IP radius server||//g')
	var_IPCam1=$(cat $1 | grep IPCam1 | sed 's/^.*IPCam1 IP|//' | sed 's/|//g')
	var_Solitax=$(cat $1 | grep Solitax | sed 's/|_&lt;.Solitax sc1000 IP|//g' | sed 's/\lt.*//' | sed 's/||_&//g')
	echo var_Tip: $var_Tip
	echo var_GW: $var_GW
		pingme $var_GW
			echo
	echo var_IP1: $var_IP1
		pingme $var_IP1
			echo
	echo var_IPCam1: $var_IPCam1
		pingme $var_IPCam1
			echo
	echo var_Solitax: $var_Solitax
		pingme $var_Solitax
			echo

}


fetchme_3000_2ComSrc_1Cam(){
	echo $1 | sed 's/textileWiki\///g'
	var_Tip=$(cat $1 | grep Tip | head -1 | sed 's/^.*Tip|//' | sed 's/|//g')
	var_GW=$(cat $1 | grep gateway | sed 's/||||//g' | sed 's/|_&lt;.gateway|//g')
	var_IP1=$(cat $1 | grep IP1 | sed 's/|_&lt;.IP1|//g' | sed 's/||_&lt;.IP radius server||//g')
	var_ComServer1=$(cat $1 | grep ComServer1 | sed 's/\IPCam1 IP.*/IPCam1 IP/' | sed 's/||_&lt;.IPCam1 IP//g' | sed 's/|_&lt;.ComServer1 IP|//g')
	var_ComServer2=$(cat $1 | grep ComServer2 | sed 's/\IPCam2 IP.*/IPCam2 IP/' | sed 's/||_&lt;.IPCam2 IP//g' | sed 's/|_&lt;.ComServer2 IP|//g')
	var_IPCam1=$(cat $1 | grep IPCam1 | sed 's/^.*IPCam1 IP|//' | sed 's/|//g')
	echo var_Tip: $var_Tip
	echo var_GW: $var_GW
		pingme $var_GW
			echo
	echo var_IP1: $var_IP1
		pingme $var_IP1
			echo
	echo var_ComServer1: $var_ComServer1
		pingme $var_ComServer1
			echo
	echo var_ComServer2: $var_ComServer2
		pingme $var_ComServer2
			echo
	echo var_IPCam1: $var_IPCam1
		pingme $var_IPCam1
			echo
}


fetchme_3000_2ComSrc_2Cam(){
	echo $1 | sed 's/textileWiki\///g'
	var_Tip=$(cat $1 | grep Tip | head -1 | sed 's/^.*Tip|//' | sed 's/|//g')
	var_GW=$(cat $1 | grep gateway | sed 's/||||//g' | sed 's/|_&lt;.gateway|//g')
	var_IP1=$(cat $1 | grep IP1 | sed 's/|_&lt;.IP1|//g' | sed 's/||_&lt;.IP radius server||//g')
	var_ComServer1=$(cat $1 | grep ComServer1 | sed 's/\IPCam1 IP.*/IPCam1 IP/' | sed 's/||_&lt;.IPCam1 IP//g' | sed 's/|_&lt;.ComServer1 IP|//g')
	var_ComServer2=$(cat $1 | grep ComServer2 | sed 's/\IPCam2 IP.*/IPCam2 IP/' | sed 's/||_&lt;.IPCam2 IP//g' | sed 's/|_&lt;.ComServer2 IP|//g')
	var_IPCam1=$(cat $1 | grep IPCam1 | sed 's/^.*IPCam1 IP|//' | sed 's/|//g')
	var_IPCam2=$(cat $1 | grep IPCam2 | sed 's/^.*IPCam2 IP|//' | sed 's/|//g')
	echo var_Tip: $var_Tip
	echo var_GW: $var_GW
		pingme $var_GW
			echo
	echo var_IP1: $var_IP1
		pingme $var_IP1
			echo
	echo var_ComServer1: $var_ComServer1
		pingme $var_ComServer1
			echo
	echo var_ComServer2: $var_ComServer2
		pingme $var_ComServer2
			echo
	echo var_IPCam1: $var_IPCam1
		pingme $var_IPCam1
			echo
	echo var_IPCam2: $var_IPCam2
		pingme $var_IPCam2
			echo
}


fetchme_3000_1ComSrc_4Cam(){
	echo $1 | sed 's/textileWiki\///g'
	var_Tip=$(cat $1 | grep Tip | head -1 | sed 's/^.*Tip|//' | sed 's/|//g')
	var_GW=$(cat $1 | grep gateway | sed 's/||||//g' | sed 's/|_&lt;.gateway|//g')
	var_IP1=$(cat $1 | grep IP1 | sed 's/|_&lt;.IP1|//g' | sed 's/||_&lt;.IP radius server||//g')
	var_ComServer1=$(cat $1 | grep ComServer1 | sed 's/\IPCam1 IP.*/IPCam1 IP/' | sed 's/||_&lt;.IPCam1 IP//g' | sed 's/|_&lt;.ComServer1 IP|//g')
	var_IPCam1=$(cat $1 | grep IPCam1 | sed 's/^.*IPCam1 IP|//' | sed 's/|//g')
	var_IPCam2=$(cat $1 | grep IPCam2 | sed 's/^.*IPCam2 IP|//' | sed 's/|//g')
	var_IPCam3=$(cat $1 | grep IPCam3 | sed 's/^.*IPCam3 IP|//' | sed 's/|//g')
	var_IPCam4=$(cat $1 | grep IPCam4 | sed 's/^.*IPCam4 IP|//' | sed 's/|//g')
	echo var_Tip: $var_Tip
	echo var_GW: $var_GW
		pingme $var_GW
			echo
	echo var_IP1: $var_IP1
		pingme $var_IP1
			echo
	echo var_ComServer1: $var_ComServer1
		pingme $var_ComServer1
			echo
	echo var_IPCam1: $var_IPCam1
		pingme $var_IPCam1
			echo
	echo var_IPCam2: $var_IPCam2
		pingme $var_IPCam2
			echo
	echo var_IPCam3: $var_IPCam3
		pingme $var_IPCam3
			echo
	echo var_IPCam4: $var_IPCam4
		pingme $var_IPCam4
			echo
}


fetchme_3000_4ComSrc_4Cam(){
	echo $1 | sed 's/textileWiki\///g'
	var_Tip=$(cat $1 | grep Tip | head -1 | sed 's/^.*Tip|//' | sed 's/|//g')
	var_GW=$(cat $1 | grep gateway | sed 's/||||//g' | sed 's/|_&lt;.gateway|//g')
	var_IP1=$(cat $1 | grep IP1 | sed 's/|_&lt;.IP1|//g' | sed 's/||_&lt;.IP radius server||//g')
	var_ComServer1=$(cat $1 | grep ComServer1 | sed 's/\IPCam1 IP.*/IPCam1 IP/' | sed 's/||_&lt;.IPCam1 IP//g' | sed 's/|_&lt;.ComServer1 IP|//g')
	var_ComServer2=$(cat $1 | grep ComServer2 | sed 's/\IPCam2 IP.*/IPCam2 IP/' | sed 's/||_&lt;.IPCam2 IP//g' | sed 's/|_&lt;.ComServer2 IP|//g')
	var_ComServer3=$(cat $1 | grep ComServer3 | sed 's/\IPCam3 IP.*/IPCam3 IP/' | sed 's/||_&lt;.IPCam3 IP//g' | sed 's/|_&lt;.ComServer3 IP|//g')
	var_ComServer4=$(cat $1 | grep ComServer4 | sed 's/\IPCam4 IP.*/IPCam4 IP/' | sed 's/||_&lt;.IPCam4 IP//g' | sed 's/|_&lt;.ComServer4 IP|//g')
	var_IPCam1=$(cat $1 | grep IPCam1 | sed 's/^.*IPCam1 IP|//' | sed 's/|//g')
	var_IPCam2=$(cat $1 | grep IPCam2 | sed 's/^.*IPCam2 IP|//' | sed 's/|//g')
	var_IPCam3=$(cat $1 | grep IPCam3 | sed 's/^.*IPCam3 IP|//' | sed 's/|//g')
	var_IPCam4=$(cat $1 | grep IPCam4 | sed 's/^.*IPCam4 IP|//' | sed 's/|//g')
	echo var_Tip: $var_Tip
	echo var_GW: $var_GW
		pingme $var_GW
			echo
	echo var_IP1: $var_IP1
		pingme $var_IP1
			echo
	echo var_ComServer1: $var_ComServer1
		pingme $var_ComServer1
			echo
	echo var_ComServer2: $var_ComServer2
		pingme $var_ComServer2
			echo
	echo var_ComServer3: $var_ComServer3
		pingme $var_ComServer3
			echo
	echo var_ComServer4: $var_ComServer4
		pingme $var_ComServer4
			echo
	echo var_IPCam1: $var_IPCam1
		pingme $var_IPCam1
			echo
	echo var_IPCam2: $var_IPCam2
		pingme $var_IPCam2
			echo
	echo var_IPCam3: $var_IPCam3
		pingme $var_IPCam3
			echo
	echo var_IPCam4: $var_IPCam4
		pingme $var_IPCam4
			echo
}


fetchme_3000_1ComSrc_3Cam(){
	echo $1 | sed 's/textileWiki\///g'
	var_Tip=$(cat $1 | grep Tip | head -1 | sed 's/^.*Tip|//' | sed 's/|//g')
	var_GW=$(cat $1 | grep gateway | sed 's/||||//g' | sed 's/|_&lt;.gateway|//g')
	var_IP1=$(cat $1 | grep IP1 | sed 's/|_&lt;.IP1|//g' | sed 's/||_&lt;.IP radius server||//g')
	var_ComServer1=$(cat $1 | grep ComServer1 | sed 's/\IPCam1 IP.*/IPCam1 IP/' | sed 's/||_&lt;.IPCam1 IP//g' | sed 's/|_&lt;.ComServer1 IP|//g')
	var_IPCam1=$(cat $1 | grep IPCam1 | sed 's/^.*IPCam1 IP|//' | sed 's/|//g')
	var_IPCam2=$(cat $1 | grep IPCam2 | sed 's/^.*IPCam2 IP|//' | sed 's/|//g')
	var_IPCam3=$(cat $1 | grep IPCam3 | sed 's/^.*IPCam3 IP|//' | sed 's/|//g')
	echo var_Tip: $var_Tip
	echo var_GW: $var_GW
		pingme $var_GW
			echo
	echo var_IP1: $var_IP1
		pingme $var_IP1
			echo
	echo var_ComServer1: $var_ComServer1
		pingme $var_ComServer1
			echo
	echo var_IPCam1: $var_IPCam1
		pingme $var_IPCam1
			echo
	echo var_IPCam2: $var_IPCam2
		pingme $var_IPCam2
			echo
	echo var_IPCam3: $var_IPCam3
		pingme $var_IPCam3
			echo
}


fetchme_3000_1ComSrc_2Cam(){
	echo $1 | sed 's/textileWiki\///g'
	var_Tip=$(cat $1 | grep Tip | head -1 | sed 's/^.*Tip|//' | sed 's/|//g')
	var_GW=$(cat $1 | grep gateway | sed 's/||||//g' | sed 's/|_&lt;.gateway|//g')
	var_IP1=$(cat $1 | grep IP1 | sed 's/|_&lt;.IP1|//g' | sed 's/||_&lt;.IP radius server||//g')
	var_ComServer1=$(cat $1 | grep ComServer1 | sed 's/\IPCam1 IP.*/IPCam1 IP/' | sed 's/||_&lt;.IPCam1 IP//g' | sed 's/|_&lt;.ComServer1 IP|//g')
	var_IPCam1=$(cat $1 | grep IPCam1 | sed 's/^.*IPCam1 IP|//' | sed 's/|//g')
	var_IPCam2=$(cat $1 | grep IPCam2 | sed 's/^.*IPCam2 IP|//' | sed 's/|//g')
	echo var_Tip: $var_Tip
	echo var_GW: $var_GW
		pingme $var_GW
			echo
	echo var_IP1: $var_IP1
		pingme $var_IP1
			echo
	echo var_ComServer1: $var_ComServer1
		pingme $var_ComServer1
			echo
	echo var_IPCam1: $var_IPCam1
		pingme $var_IPCam1
			echo
	echo var_IPCam2: $var_IPCam2
		pingme $var_IPCam2
			echo
}


fetchme_3000_1ComSrc_1Cam(){
	echo $1 | sed 's/textileWiki\///g'
	var_Tip=$(cat $1 | grep Tip | head -1 | sed 's/^.*Tip|//' | sed 's/|//g')
	var_GW=$(cat $1 | grep gateway | sed 's/||||//g' | sed 's/|_&lt;.gateway|//g')
	var_IP1=$(cat $1 | grep IP1 | sed 's/|_&lt;.IP1|//g' | sed 's/||_&lt;.IP radius server||//g')
	var_ComServer1=$(cat $1 | grep ComServer1 | sed 's/\IPCam1 IP.*/IPCam1 IP/' | sed 's/||_&lt;.IPCam1 IP//g' | sed 's/|_&lt;.ComServer1 IP|//g')
	var_IPCam1=$(cat $1 | grep IPCam1 | sed 's/^.*IPCam1 IP|//' | sed 's/|//g')
	echo var_Tip: $var_Tip
	echo var_GW: $var_GW
		pingme $var_GW
			echo
	echo var_IP1: $var_IP1
		pingme $var_IP1
			echo
	echo var_ComServer1: $var_ComServer1
		pingme $var_ComServer1
			echo
	echo var_IPCam1: $var_IPCam1
		pingme $var_IPCam1
			echo
}


fetchme_3000_3Cam(){
	echo $1 | sed 's/textileWiki\///g'
	var_Tip=$(cat $1 | grep Tip | head -1 | sed 's/^.*Tip|//' | sed 's/|//g')
	var_GW=$(cat $1 | grep gateway | sed 's/||||//g' | sed 's/|_&lt;.gateway|//g')
	var_IP1=$(cat $1 | grep IP1 | sed 's/|_&lt;.IP1|//g' | sed 's/||_&lt;.IP radius server||//g')
	var_ComServer1=$(cat $1 | grep ComServer1 | sed 's/\IPCam1 IP.*/IPCam1 IP/' | sed 's/||_&lt;.IPCam1 IP//g' | sed 's/|_&lt;.ComServer1 IP|//g')
	var_IPCam1=$(cat $1 | grep IPCam1 | sed 's/^.*IPCam1 IP|//' | sed 's/|//g')
	var_IPCam2=$(cat $1 | grep IPCam2 | sed 's/^.*IPCam2 IP|//' | sed 's/|//g')
	var_IPCam3=$(cat $1 | grep IPCam3 | sed 's/^.*IPCam3 IP|//' | sed 's/|//g')
	echo var_Tip: $var_Tip
	echo var_GW: $var_GW
		pingme $var_GW
			echo
	echo var_IP1: $var_IP1
		pingme $var_IP1
			echo
	echo var_ComServer1: $var_ComServer1
		pingme $var_ComServer1
			echo
	echo var_IPCam1: $var_IPCam1
		pingme $var_IPCam1
			echo
	echo var_IPCam2: $var_IPCam2
		pingme $var_IPCam2
			echo
	echo var_IPCam3: $var_IPCam3
		pingme $var_IPCam3
			echo
}


fetchme_3000_2Cam(){
	echo $1 | sed 's/textileWiki\///g'
	var_Tip=$(cat $1 | grep Tip | head -1 | sed 's/^.*Tip|//' | sed 's/|//g')
	var_GW=$(cat $1 | grep gateway | sed 's/||||//g' | sed 's/|_&lt;.gateway|//g')
	var_IP1=$(cat $1 | grep IP1 | sed 's/|_&lt;.IP1|//g' | sed 's/||_&lt;.IP radius server||//g')
	var_ComServer1=$(cat $1 | grep ComServer1 | sed 's/\IPCam1 IP.*/IPCam1 IP/' | sed 's/||_&lt;.IPCam1 IP//g' | sed 's/|_&lt;.ComServer1 IP|//g')
	var_IPCam1=$(cat $1 | grep IPCam1 | sed 's/^.*IPCam1 IP|//' | sed 's/|//g')
	var_IPCam2=$(cat $1 | grep IPCam2 | sed 's/^.*IPCam2 IP|//' | sed 's/|//g')
	echo var_Tip: $var_Tip
	echo var_GW: $var_GW
		pingme $var_GW
			echo
	echo var_IP1: $var_IP1
		pingme $var_IP1
			echo
	echo var_ComServer1: $var_ComServer1
		pingme $var_ComServer1
			echo
	echo var_IPCam1: $var_IPCam1
		pingme $var_IPCam1
			echo
	echo var_IPCam2: $var_IPCam2
		pingme $var_IPCam2
			echo
}


fetchme_3000_1Cam(){
	echo $1 | sed 's/textileWiki\///g'
	var_Tip=$(cat $1 | grep Tip | head -1 | sed 's/^.*Tip|//' | sed 's/|//g')
	var_GW=$(cat $1 | grep gateway | sed 's/||||//g' | sed 's/|_&lt;.gateway|//g')
	var_IP1=$(cat $1 | grep IP1 | sed 's/|_&lt;.IP1|//g' | sed 's/||_&lt;.IP radius server||//g')
	var_ComServer1=$(cat $1 | grep ComServer1 | sed 's/\IPCam1 IP.*/IPCam1 IP/' | sed 's/||_&lt;.IPCam1 IP//g' | sed 's/|_&lt;.ComServer1 IP|//g')
	var_IPCam1=$(cat $1 | grep IPCam1 | sed 's/^.*IPCam1 IP|//' | sed 's/|//g')
	echo var_Tip: $var_Tip
	echo var_GW: $var_GW
		pingme $var_GW
			echo
	echo var_IP1: $var_IP1
		pingme $var_IP1
			echo
	echo var_ComServer1: $var_ComServer1
		pingme $var_ComServer1
			echo
	echo var_IPCam1: $var_IPCam1
		pingme $var_IPCam1
			echo
}


fetchme_3000(){
	echo $1 | sed 's/textileWiki\///g'
	var_Tip=$(cat $1 | grep Tip | head -1 | sed 's/^.*Tip|//' | sed 's/|//g')
	var_GW=$(cat $1 | grep gateway | sed 's/||||//g' | sed 's/|_&lt;.gateway|//g')
	var_IP1=$(cat $1 | grep IP1 | sed 's/|_&lt;.IP1|//g' | sed 's/||_&lt;.IP radius server||//g')
	var_ComServer1=$(cat $1 | grep ComServer1 | sed 's/\IPCam1 IP.*/IPCam1 IP/' | sed 's/||_&lt;.IPCam1 IP//g' | sed 's/|_&lt;.ComServer1 IP|//g')
	echo var_Tip: $var_Tip
	echo var_GW: $var_GW
		pingme $var_GW
			echo
	echo var_IP1: $var_IP1
		pingme $var_IP1
			echo
	echo var_ComServer1: $var_ComServer1
		pingme $var_ComServer1
			echo
}


fetchme_sp(){
	echo $1 | sed 's/textileWiki\///g'
	var_Tip=$(cat $1 | grep Tip | head -1 | sed 's/^.*Tip|//' | sed 's/|//g')
	var_IPradiusServer=$(cat $1 | grep IP1 | sed 's/|_&lt;.IP1 (service port)|192.168.5.127||_&lt;.IP radius server//g' | sed 's/|//g')
	echo var_Tip: $var_Tip
	echo var_IPradiusServer: $var_IPradiusServer
		pingme $var_IPradiusServer
			echo
}





echo
echo
echo START.........................................................................................................

#var_presta="presta1.html" # <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<   P R E S T A   F I L E   <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
var_presta=$1 # <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<   P R E S T A   F I L E   <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
cat $var_presta | grep 'VPIS PODATKOV' > header.xml

var_Header=$(cat header.xml)
var_FROM=$(cat header.xml | grep -b -o 'BAZO od' |cut -f1 -d:) # extract 1.field :delimiter
var_TO=$(cat header.xml | grep -b -o '(UTC+1) do' |cut -f1 -d:)

var_time_start=${var_Header:$var_FROM+8:16}
var_time_end=${var_Header:$var_TO+11:16}
#	echo "var_time_start: " $var_time_start
#	echo "var_time_end: " $var_time_end


F1(){
	#echo Station: $1
	var_PREVIOUS_FROM=$(cat $var_presta | grep -n "$1" |cut -f1 -d: | head -1)
	var_TARGET_FROM=$(cat $var_presta | grep -n "$2" |cut -f1 -d: | head -1)
#			echo "var_PREVIOUS_FROM: " $var_PREVIOUS_FROM
#			echo "var_TARGET_FROM: " $var_TARGET_FROM
	cat $var_presta | sed -n "$var_PREVIOUS_FROM,$((var_TARGET_FROM-1)) p" > TARGET.xml
	tr -d ' \t\n\r\f' <TARGET.xml >_TARGET.xml
		mv _TARGET.xml TARGET.xml
	cat TARGET.xml | sed 's/\/td>/\/td>\n/g' > _TARGET.xml
		mv _TARGET.xml TARGET.xml
	cat TARGET.xml | sed 's/tdbg/td bg/g' > _TARGET.xml
		mv _TARGET.xml TARGET.xml

	var_ParNumNominal=$(cat TARGET.xml | grep 'E8C0C0' |cut -f1 -d: | grep -o -P '(?<=<b>).*(?=</b>)' | head -1)
#		echo "var_ParNumNominal: " $var_ParNumNominal
	var_CutPosition=$(cat TARGET.xml | grep -n 'E8C0C0' |cut -f1 -d: | tail -1)
#		echo "var_CutPosition" $var_CutPosition
	cat TARGET.xml | tail -n +$(($var_CutPosition+1)) > _TARGET.xml
		mv _TARGET.xml TARGET.xml
	cat TARGET.xml | head -48 > _TARGET.xml
		mv _TARGET.xml TARGET.xml
	cat TARGET.xml | sed 's/<td bgcolor=//g' > _TARGET.xml
		mv _TARGET.xml TARGET.xml
	cat TARGET.xml | sed 's/<td>//g' > _TARGET.xml
		mv _TARGET.xml TARGET.xml
	cat TARGET.xml | sed 's/<\/td>//g' > _TARGET.xml
		mv _TARGET.xml TARGET.xml
	cat TARGET.xml | sed 's/>//g' > _TARGET.xml
		mv _TARGET.xml TARGET.xml
	cat TARGET.xml | sed 's/=.*//' > _TARGET.xml
		mv _TARGET.xml TARGET.xml	
		cp TARGET.xml TEMP/TARGET_$1.xml 

	cat $var_presta | grep 'face=Ariel' | head -1 > period.xml
	cat period.xml | sed 's/<\/td><th  ><font  face=Ariel size=4>/:/g' > _period.xml
		mv _period.xml period.xml
	cat period.xml | sed 's/ <br> /_/g' > _period.xml
		mv _period.xml period.xml
	cat period.xml | sed 's/<th  ><font  face=Ariel size=4>/_/g' > _period.xml
		mv _period.xml period.xml
	cat period.xml | sed 's/<\/td> <\/tr>/_/g' > _period.xml
		mv _period.xml period.xml
	tr -d ' \t\n\r\f' <period.xml >_period.xml
		mv _period.xml period.xml
	cat period.xml | sed 's/_/ /g' > _period.xml
		mv _period.xml period.xml
	tr -d ' \t\n\r\f' <period.xml >_period.xml
		mv _period.xml period.xml
	cat period.xml | sed 's/:/ /g' > _period.xml
		mv _period.xml period.xml
	cat period.xml | sed 's/ /\n/g' > _period.xml
		mv _period.xml period.xml
	sed 's/./&:/2' period.xml > _period.xml		
		mv _period.xml period.xml		

	IFS=$'\n' read -d '' -r -a arr_TARGET_time < period.xml
	IFS=$'\n' read -d '' -r -a arr_TARGET_values < TARGET.xml

	var_pos_TARGET="OK"

	for ((i=47; i>=0; i--))
	do
		: 
		if [[ ${arr_TARGET_values[$i]} == *"Redtitle"* ]]; then
			var_pos_TARGET=${arr_TARGET_time[$i]}
		else
			break
		fi
	done

	if [[ $var_pos_TARGET != "OK" ]]; then
		echo "Station: " $1
		echo $var_pos_TARGET
		
		if [[ $3 == "f_230" ]]; then
			fetchme_230 $4
		fi
		if [[ $3 == "f_230_1Cam" ]]; then
			fetchme_230_1Cam $4
		fi
		if [[ $3 == "f_230_1ComSrv_1Cam" ]]; then
			fetchme_230_1ComSrv_1Cam $4
		fi
		if [[ $3 == "f_230_1Cam_Solitax" ]]; then
			fetchme_230_1Cam_Solitax $4
		fi
		if [[ $3 == "f_3000_2ComSrc_1Cam" ]]; then
			fetchme_3000_2ComSrc_1Cam $4
		fi
		if [[ $3 == "f_3000_2ComSrc_2Cam" ]]; then
			fetchme_3000_2ComSrc_2Cam $4
		fi
		if [[ $3 == "f_3000_1ComSrc_4Cam" ]]; then
			fetchme_3000_1ComSrc_4Cam $4
		fi
		if [[ $3 == "f_3000_4ComSrc_4Cam" ]]; then
			fetchme_3000_4ComSrc_4Cam $4
		fi
		if [[ $3 == "f_3000_1ComSrc_3Cam" ]]; then
			fetchme_3000_1ComSrc_3Cam $4
		fi
		if [[ $3 == "f_3000_1ComSrc_2Cam" ]]; then
			fetchme_3000_1ComSrc_2Cam $4
		fi
		if [[ $3 == "f_3000_1ComSrc_1Cam" ]]; then
			fetchme_3000_1ComSrc_1Cam $4
		fi
		if [[ $3 == "f_3000_3Cam" ]]; then
			fetchme_3000_3Cam $4
		fi
		if [[ $3 == "f_3000_2Cam" ]]; then
			fetchme_3000_2Cam $4
		fi
		if [[ $3 == "f_3000_1Cam" ]]; then
			fetchme_3000_1Cam $4
		fi
		if [[ $3 == "f_3000" ]]; then
			fetchme_3000 $4
		fi
		if [[ $3 == "f_sp" ]]; then
			fetchme_sp $4
		fi

		
		echo ---------------\|
	fi
}

F2(){
cat presta.html | grep $1 > temp.txt
cat temp.txt | sed 's/<td>G4/\n<td>G4/g' > _temp.txt
	mv _temp.txt temp.txt
cat temp.txt | grep G401 > _temp.txt
	mv _temp.txt temp.txt
cat temp.txt | sed 's/<td>G4/\n<td>G4/g' > _temp.txt
	mv _temp.txt temp.txt

cat temp.txt | sed 's/.*E8C0C0//' > _temp.txt
	mv _temp.txt temp.txt
cat temp.txt | sed 's/<tr><td>2<\/td>//' > _temp.txt
	mv _temp.txt temp.txt
cat temp.txt | sed 's/<\/td><td>/\n/g' > _temp.txt
	mv _temp.txt temp.txt
cat temp.txt | sed 's/><b>6<\/b>//g' > _temp.txt
	mv _temp.txt temp.txt
cat temp.txt | sed 's|</td>||' > _temp.txt
	mv _temp.txt temp.txt
cat temp.txt | sed '/^$/d' > _temp.txt
	mv _temp.txt temp.txt
	cp temp.txt TEMP/TARGET_$1.xml 

	for ((i=0; i>=23; i++))
	do
		: 
	done
	IFS=$'\n' read -d '' -r -a arr_TARGET_values < TEMP/TARGET_$1.xml
	cat period.xml | sed -n -e 'p;N;d;' > periodG.xml # every second line...

	var_pos_TARGET="OK"

	for ((i=23; i>=0; i--))
	do
		: 
		if [[ ${arr_TARGET_values[$i]} == *"Redtitle"* ]]; then
			var_pos_TARGET=${arr_TARGET_time[$i]}
		else
			break
		fi
	done

	if [[ $var_pos_TARGET != "OK" ]]; then
		echo "Station: " $1
		echo $var_pos_TARGET
		
		if [[ $3 == "f_230" ]]; then
			fetchme_230 $4
		fi
		if [[ $3 == "f_230_1Cam" ]]; then
			fetchme_230_1Cam $4
		fi
		if [[ $3 == "f_230_1ComSrv_1Cam" ]]; then
			fetchme_230_1ComSrv_1Cam $4
		fi
		if [[ $3 == "f_230_1Cam_Solitax" ]]; then
			fetchme_230_1Cam_Solitax $4
		fi
		if [[ $3 == "f_sp" ]]; then
			fetchme_sp $4
		fi
		
		
		echo ---------------\|
	fi
}

RUN_H(){
	F1 "H401" "H402" f_sp "textileWiki/11/08332_H401_Tolmin_I_Tolminka.xml"
	F1 "H402" "H403" f_sp "textileWiki/09/04750_H402_Rakovec_Sotla.xml"
	F1 "H403" "H404" f_sp "textileWiki/04/02372_H403_Dovze_II_Mislinja.xml"
	F1 "H404" "H405" f_sp "textileWiki/12/08561_H404_Vipava_II_Vipava.xml"
	F1 "H405" "H406" f_230_1Cam_Solitax "textileWiki/16/06210_H405_Veliko_Sirje_I_Savinja.xml"
	F1 "H406" "H407" f_230_1Cam_Solitax "textileWiki/16/03725_H406_Hrastnik_Sava.xml"
	F1 "H407" "H408" f_sp "textileWiki/11/02250_H407_Otiski_Vrh_I_Meza.xml"
	F1 "H408" "H409" f_230_1Cam "textileWiki/13/04222_H408_Ziri_III_Poljanska_Sora.xml"
	F1 "H409" "H41"  f_sp "textileWiki/07/04671_H409_Martinja_vas_II_Mirna.xml"
	F1 "H410" "H411" f_sp "textileWiki/11/07060_H410_Soteska_Krka.xml"
	F1 "H411" "H412" f_230_1Cam "textileWiki/14/03660_H411_Litija_Sava.xml"
	F1 "H412" "H413" f_sp "textileWiki/09/05030_H412_Vrhnika_Ljubljanica.xml"
	F1 "H413" "H414" f_sp "textileWiki/04/04960_H413_Livold_I_Rinza.xml"
	F1 "H414" "H415" f_sp "textileWiki/16/09050_H414_Cerkvenikov_mlin_Reka.xml"
	F1 "H415" "H416" f_230_1Cam "textileWiki/13/02150_H415_Borl_I_Drava.xml"
	F1 "H416" "H417" f_sp "textileWiki/13/02160_H416_Zavrc_Drava.xml"
	F1 "H417" "H418" f_230_1Cam "textileWiki/13/04828_H417_Sodevci_Kolpa.xml"
	F1 "H418" "H419" f_sp "textileWiki/14/08450_H418_Hotesk_Idrijca.xml"
	F1 "H419" "H420" f_230_1Cam "textileWiki/16/06240_H419_Krase_Dreta.xml"
	F1 "H420" "H421" f_sp "textileWiki/09/07110_H420_Gorenja_Gomila_Krka.xml"
	F1 "H421" "H422" f_sp "textileWiki/06/03250_H421_Bodesce_Sava_Bohinjka.xml"
	F1 "H422" "H423" f_sp "textileWiki/04/04706_H422_Metni_vrh_Sevnicna.xml"
	F1 "H423" "H424" f_sp "textileWiki/13/05680_H423_Dolenje_Jezero_Strzen.xml"
	F1 "H424" "H425" f_sp "textileWiki/07/08478_H424_Dolenja_Trebusa_I_Trebusa.xml"
	F1 "H425" "H426" f_sp "textileWiki/16/08690_H425_Golo_Brdo_Idrija.xml"
	F1 "H426" "H427" f_sp "textileWiki/09/05040_H426_Kamin_Ljubljanica.xml"
	F1 "H427" "H428" f_sp "textileWiki/13/07029_H427_Podbukovje_I_Krka.xml"
	F1 "H428" "H429" f_sp "textileWiki/12/08710_H428_Potoki_Nadiza.xml"
	F1 "H429" "H43"  f_230_1Cam "textileWiki/16/04120_H429_Kokra_I_Kokra.xml"
	F1 "H430" "H431" f_sp "textileWiki/14/06550_H430_Dolenja_vas_II_Bolska.xml"
	F1 "H431" "H432" f_230_1Cam "textileWiki/07/08060_H431_Log_Cezsoski_Soca.xml"
	F1 "H432" "H433" f_230_1Cam "textileWiki/13/08601_H432_Miren_I_Vipava.xml"
	F1 "H433" "H434" f_sp "textileWiki/18/08080_H433_Kobarid_I_Soca.xml"
	F1 "H434" "H435" f_230_1Cam "textileWiki/13/05500_H434_Dvor_Gradascica.xml"
	F1 "H435" "H436" f_sp "textileWiki/14/01220_H435_Polana_I_Ledava.xml"
	F1 "H436" "H437" f_sp "textileWiki/16/08500_H436_Baca_pri_Modreju_Baca.xml"
	F1 "H437" "H438" f_230_1Cam "textileWiki/13/07160_H437_Podbocje_Krka.xml"
	F1 "H438" "H439" f_230_1Cam "textileWiki/14/08350_H438_Podroteja_I_Idrijca.xml"
	F1 "H439" "H440" f_sp "textileWiki/07/03060_H439_Jesenice_Sava_Dolinka.xml"
	F1 "H440" "H441" f_sp "textileWiki/19/06300_H440_Sostanj_Paka.xml"
	F1 "H441" "H442" f_sp "textileWiki/14/01100_H441_Cankova_Kucnica.xml"
	F1 "H442" "H443" f_sp "textileWiki/11/09300_H442_Podkastel_Dragonja.xml"
	F1 "H443" "H444" f_sp "textileWiki/04/06340_H443_Recica_Paka.xml"
	F1 "H444" "H445" f_sp "textileWiki/03/09030_H444_Trnovo_Reka.xml"
	F1 "H445" "H446" f_230_1Cam "textileWiki/13/03180_H445_Podhom_Radovna.xml"
	F1 "H446" "H447" f_sp "textileWiki/07/04515_H446_Vir_Raca.xml"
	F1 "H447" "H448" f_sp "textileWiki/04/08700_H447_Neblo_Kozbanjscek.xml"
	F1 "H448" "H449" f_sp "textileWiki/19/01312_H448_Kobilje_I_Kobiljski_potok.xml"
	F1 "H449" "H45"  f_230_1Cam "textileWiki/19/03465_H449_Okroglo_Sava.xml"
	F1 "H450" "H451" f_230_1Cam "textileWiki/13/03280_H450_Sveti_Duh_Bohinjsko_jezero.xml"
	F1 "H451" "H452" f_sp "textileWiki/14/05940_H451_Logatec_Logascica.xml"
	F1 "H452" "H453" f_sp "textileWiki/03/09240_H452_Dekani_Rizana.xml"
	F1 "H453" "H454" f_sp "textileWiki/09/03014_H453_Kranjska_Gora_I_Sava_Dolinka.xml"
	F1 "H454" "H455" f_sp "textileWiki/16/06720_H454_Celje_II_Voglajna.xml"
	F1 "H455" "H456" f_sp "textileWiki/05/02652_H455_Videm_Dravinja.xml"
	F1 "H456" "H457" f_sp "textileWiki/02/04860_H456_Metlika_Kolpa.xml"
	F1 "H457" "H458" f_sp "textileWiki/12/05880_H457_Hasberg_Unica.xml"
	F1 "H458" "H459" f_sp "textileWiki/18/06790_H458_Skofja_Vas_Hudinja.xml"
	F1 "H459" "H460" f_sp "textileWiki/14/02600_H459_Zrece_Dravinja.xml"
	F1 "H460" "H461" f_sp "textileWiki/07/03320_H460_Bohinjska_Bistrica_Bistrica.xml"
	F1 "H461" "H462" f_sp "textileWiki/13/04695_H461_Jelovec_Mirna.xml"
	F1 "H462" "H463" f_sp "textileWiki/13/04969_H462_Gradac_I_Lahinja.xml"
	F1 "H463" "H464" f_230_1Cam "textileWiki/16/05240_H463_Verd_I_Ljubija.xml"
	F1 "H464" "H465" f_sp "textileWiki/13/05770_H464_Cerknica_I_Cerkniscica.xml"
	F1 "H465" "H466" f_sp "textileWiki/04/06415_H465_Gaberke_Velunja.xml"
	F1 "H466" "H467" f_sp "textileWiki/03/08591_H466_Zalosce_Vipava.xml"
	F1 "H467" "H468" f_sp "textileWiki/05/08660_H467_Volcja_Draga_Lijak.xml"
	F1 "H468" "H469" f_sp "textileWiki/13/06220_H468_Luce_Lucnica.xml"
	F1 "H469" "H470" f_sp "textileWiki/11/01300_H469_Martjanci_Martjanski_potok.xml"
	F1 "H470" "H471" f_230_1Cam "textileWiki/13/02667_H470_Perovec_Oplotnica.xml"
	F1 "H471" "H472" f_sp "textileWiki/13/02880_H471_Gocova_Pesnica.xml"
	F1 "H472" "H473" f_sp "textileWiki/09/05670_H472_Gorenje_Jezero_Strzen.xml"
	F1 "H473" "H474" f_sp "textileWiki/12/05820_H473_Postojnska_jama_Pivka.xml"
	F1 "H474" "H475" f_230_1Cam_Solitax "textileWiki/14/02390_H474_Otiski_Vrh_I_Mislinja.xml"
	F1 "H475" "H476" f_230_1Cam "textileWiki/14/02220_H475_Crna_Meza.xml"
	F1 "H476" "H477" f_230_1Cam "textileWiki/14/08630_H476_Ajdovscina_I_Hubelj.xml"
	F1 "H477" "H478" f_230_1Cam "textileWiki/16/06020_H477_Solcava_I_Savinja.xml"
	F1 "H478" "H479" f_sp "textileWiki/02/07308_H478_Rozni_Vrh_I_Temenica.xml"
	F1 "H479" "H480" f_sp "textileWiki/04/07440_H479_Sodrazica_Bistrica.xml"
	F1 "H480" "H481" f_230_1Cam "textileWiki/13/05479_H480_Bokalce_Gradascica.xml"
	F1 "H481" "H482" f_sp "textileWiki/05/09275_H481_Salara_Badasevica.xml"
	F1 "H482" "H483" f_sp "textileWiki/11/07380_H482_Skocjan_Radulja.xml"
	F1 "H483" "H484" f_230_1Cam_Solitax "textileWiki/13/02640_H483_Makole_Dravinja.xml"
	F1 "H484" "H485" f_sp "textileWiki/11/02754_H484_Trzec_Polskava.xml"
	F1 "H485" "H486" f_230_1Cam "textileWiki/13/08680_H485_Neblo_Reka.xml"
	F1 "H486" "H487" f_sp "textileWiki/09/01165_H486_Nuskova_Ledava.xml"
	F1 "H487" "H488" f_sp "textileWiki/12/05270_H487_Bistra_I_Bistra.xml"
	F1 "H488" "H489" f_sp "textileWiki/18/06140_H488_Celje_II-brv_Savinja.xml" ### 230V sa GSM!!
	F1 "H489" "H490" f_sp "textileWiki/06/03400_H489_Mlino_I_Jezernica.xml"
	F1 "H490" "H491" f_sp "textileWiki/11/04155_H490_Kranj_II_Kokra.xml"
	F1 "H491" "H492" f_sp "textileWiki/13/04209_H491_Medvode_II_Sora.xml"
	F1 "H492" "H493" f_sp "textileWiki/09/04298_H492_Vester_Selska_Sora.xml"
	F1 "H493" "H494" f_sp "textileWiki/16/04480_H493_Nevlje_I_Nevljica.xml"
	F1 "H494" "H495" f_sp "textileWiki/11/04791_H494_Zagaj_II_Bistrica.xml"
	F1 "H495" "H496" f_sp "textileWiki/14/05540_H495_Razori_Sujica.xml"
	F1 "H496" "H497" f_sp "textileWiki/09/05800_H496_Prestranek_Pivka.xml"
	F1 "H497" "H498" f_sp "textileWiki/05/06280_H497_Velenje_Paka.xml"
	F1 "H498" "H499" f_sp "textileWiki/13/06770_H498_Polze_Hudinja.xml"
	F1 "H499" "H50"  f_230_1Cam "textileWiki/19/06835_H499_Vodisko_I_Gracninca.xml"
	F1 "H500" "H501" f_sp "textileWiki/13/07272_H500_Meniska_vas_I_Radesca.xml"
	F1 "H501" "H502" f_sp "textileWiki/19/05910_H501_Malni_Malenscica.xml"
	F1 "H502" "H503" f_sp "textileWiki/13/03260_H502_Ukanc_Savica.xml"
	F1 "H503" "H504" f_230_1Cam "textileWiki/16/05440_H503_Ig_Izica.xml"
	F1 "H504" "H505" f_sp "textileWiki/13/01335_H504_Sredisce_Ivanjsevski_potok.xml"
	F1 "H505" "H506" f_sp "textileWiki/13/02420_H505_Stari_Trg_I_Suhodolnica.xml"
	F1 "H506" "H507" f_sp "textileWiki/14/03300_H506_Stara_Fuzina_II_Mostnica.xml"
	F1 "H507" "H508" f_sp "textileWiki/07/04650_H507_Zebnik_Sopota.xml"
	F1 "H508" "H509" f_sp "textileWiki/03/05330_H508_Borovnica_III_Borovniscica.xml"
	F1 "H509" "H51"  f_sp "textileWiki/12/05840_H509_Mali_Otok_Nanoscica.xml"
	F1 "H510" "H511" f_230_1Cam "textileWiki/11/07200_H510_Mlacevo_Grosupeljscica.xml"
	F1 "H511" "H512" f_sp "textileWiki/13/07220_H511_Rasica_Rasica.xml"
	F1 "H512" "H513" f_sp "textileWiki/06/07235_H512_Ivancna_Gorica_Visnjica.xml"
	F1 "H513" "H514" f_sp "textileWiki/07/07488_H513_Prigorica_I_Ribnica.xml"
	F1 "H514" "H515" f_sp "textileWiki/17/08610_H514_Podnanos_Mocilnik.xml"
	F1 "H515" "H516" f_230_1Cam "textileWiki/14/08640_H515_Branik_Branica.xml"
	F1 "H516" "H517" f_230_1Cam "textileWiki/13/09100_H516_Ilirska_Bistrica_Bistrica.xml"
	F1 "H517" "H518" f_sp "textileWiki/02/08670_H517_Bezovljak_Vogrscek.xml"
	F1 "H518" "H519" f_sp "textileWiki/13/09280_H518_Pisine_I_Drnica.xml"
	F1 "H519" "H52"  f_sp "textileWiki/14/07498_H519_Blate_Rakitnica.xml"
	F1 "H520" "H521" f_sp "textileWiki/14/04575_H520_Trzin_Psata.xml"
	F1 "H521" "H522" f_sp "textileWiki/16/03850_H521_Catez_I_Sava.xml"
	F1 "H522" "H523" f_sp "textileWiki/11/04430_H522_Vir_Kamniska_Bistrica.xml"
	F1 "H523" "H524" f_sp "textileWiki/14/04445_H523_Bisce_Kamniska_Bistrica.xml"
	F1 "H524" "H525" f_230_1Cam "textileWiki/13/04710_H524_Rogatec_Sotla.xml"
	F1 "H525" "H526" f_sp "textileWiki/13/02693_H525_Spodnja_Loznica_Loznica.xml"
	F1 "H526" "H527" f_sp "textileWiki/11/09108_H526_Zarecica_Molja.xml"
	F1 "H527" "H528" f_sp "textileWiki/14/04820_H527_Petrina_Kolpa.xml"
	F1 "H528" "H529" f_sp "textileWiki/14/09015_H528_Trpcane_Reka.xml"
	F1 "H529" "H53"  f_230_1Cam_Solitax "textileWiki/19/09210_H529_Kubed_II_Rizana.xml"
	F1 "H530" "H531" f_230_1Cam_Solitax "textileWiki/12/04200_H530_Suha_I_Sora.xml"
	F1 "H531" "H532" f_sp "textileWiki/03/08031_H531_Krsovec_I_Soca.xml"
	F1 "H532" "H533" f_sp "textileWiki/19/02900_H532_Zamusani_I_Pesnica.xml"
	F1 "H533" "H534" f_230_1Cam "textileWiki/17/04400_H533_Kamnik_I_Kamniska_Bistrica.xml"
	F1 "H534" "H535" f_230_1Cam "textileWiki/12/06060_H534_Nazarje_Savinja.xml"
	F1 "H535" "H536" f_230_1ComSrv_1Cam "textileWiki/12/02432_H535_Muta_I_Bistrica.xml"
	F1 "H536" "H537" f_sp "textileWiki/14/04230_H536_Zminec_Poljanska_Sora.xml"
	F1 "H537" "H538" f_sp "textileWiki/19/03350_H537_Mlino_Blejsko_jezero.xml" ### 230V sa GSM!!
	F1 "H538" "H539" f_sp "textileWiki/14/04025_H538_Ovsise_II_Lipnica.xml"
	F1 "H539" "H54"  f_sp "textileWiki/19/07340_H539_Precna_Precna.xml"
	F1 "H540" "H541" f_sp "textileWiki/19/06630_H540_Levec_I_Loznica.xml"
	F1 "H541" "H542" f_sp "textileWiki/19/08351_H541_Podroteja_Idrijca-Kanal.xml"
	F1 "H542" "H543" f_230_1Cam "textileWiki/12/01060_H542_Gornja_Radgona_I_Mura.xml"
	F1 "H543" "H544" f_sp "textileWiki/14/04570_H543_Topole_Psata.xml"
	F1 "H544" "H545" f_sp "textileWiki/14/04520_H544_Podrecje_Raca.xml"
	F1 "H545" "H550" f_sp "textileWiki/19/08545_H545_Nova_Gorica_I_Koren.xml" ### 230V sa GSM!!
	#F1 "H550" "H551"
	#F1 "H551" "H56"
}

RUN_M(){
	F1 "M401" "M402" f_3000 "textileWiki/10/00164_M401_Babno_Polje.xml"
	F1 "M402" "M403" f_3000_2ComSrc_1Cam "textileWiki/06/00097_M402_Bilje.xml"
	F1 "M403" "M404" f_3000_3Cam "textileWiki/17/00819_M403_Blegos.xml"
	F1 "M404" "M405" f_3000 "textileWiki/11/00482_M404_Bohinjska_Cesnjica.xml"
	F1 "M405" "M406" f_3000 "textileWiki/11/00061_M405_Breginj.xml"
	F1 "M406" "M407" f_3000 "textileWiki/10/00812_M406_Bukovski_vrh.xml"
	F1 "M407" "M408" f_3000_1Cam "textileWiki/10/00831_M407_Cerknisko_jezero.xml"
	F1 "M408" "M409" f_3000 "textileWiki/02/00832_M408_Zadlog.xml"
	F1 "M409" "M410" f_3000 "textileWiki/04/00021_M409_Davca.xml"
	F1 "M410" "M411" f_3000 "textileWiki/16/00826_M410_Marinca_vas.xml"
	F1 "M411" "M412" f_3000 "textileWiki/06/00555_M411_Gacnik.xml"
	F1 "M412" "M413" f_3000 "textileWiki/11/00107_M412_Godnje.xml"
	F1 "M413" "M414" f_3000_3Cam "textileWiki/10/00275_M413_Radegunda.xml"
	F1 "M414" "M415" f_3000 "textileWiki/10/00276_M414_Gornji_Grad.xml"
	F1 "M415" "M416" f_3000_1ComSrc_2Cam "textileWiki/04/00653_M415_Hocko_Pohorje.xml"
	F1 "M416" "M417" f_3000 "textileWiki/19/00559_M416_Idrija.xml"
	F1 "M417" "M418" f_3000 "textileWiki/02/00498_M417_Iskrba.xml"
	F1 "M418" "M419" f_3000 "textileWiki/18/00030_M418_Jelendol.xml"
	F1 "M419" "M420" f_3000 "textileWiki/06/00272_M419_Jeronim.xml"
	F1 "M420" "M421" f_3000_3Cam "textileWiki/10/00348_M420_Jeruzalem.xml"
	F1 "M421" "M422" f_3000 "textileWiki/16/00133_M421_Jursce.xml"
	F1 "M422" "M423" f_3000 "textileWiki/04/00339_M422_Kadrenci.xml"
	F1 "M423" "M424" f_3000 "textileWiki/13/00820_M423_Kamniska_Bistrica.xml"
	F1 "M424" "M425" f_3000_1ComSrc_3Cam "textileWiki/09/00436_M424_Kanin.xml"
	F1 "M425" "M426" f_3000 "textileWiki/04/00068_M425_Kneske_ravne.xml"
	F1 "M426" "M427" f_3000 "textileWiki/10/00174_M426_Kocevje.xml"
	F1 "M427" "M428" f_3000 "textileWiki/11/00251_M427_Kocevske_Poljane.xml"
	F1 "M428" "M429" f_3000_1ComSrc_2Cam "textileWiki/18/00823_M428_Korensko_sedlo.xml"
	F1 "M429" "M430" f_3000 "textileWiki/02/00656_M429_Kranj.xml"
	F1 "M430" "M431" f_3000_2ComSrc_2Cam "textileWiki/10/00048_M430_Kredarica.xml"
	F1 "M431" "M432" f_3000_3Cam "textileWiki/10/00065_M431_Krn.xml"
	F1 "M432" "M433" f_3000_2ComSrc_2Cam "textileWiki/16/00003_M432_Krvavec.xml"
	F1 "M433" "M434" f_3000 "textileWiki/13/00121_M433_Kubed.xml"
	F1 "M434" "M435" f_3000_3Cam "textileWiki/18/00210_M434_Kum.xml"
	F1 "M435" "M436" f_3000_4ComSrc_4Cam "textileWiki/18/00452_M435_Lisca.xml"
	F1 "M436" "M437" f_3000 "textileWiki/09/00206_M436_Litija.xml"
	F1 "M437" "M438" f_3000_2Cam "textileWiki/10/00280_M437_Logarska_dolina.xml"
	F1 "M438" "M439" f_3000 "textileWiki/02/00147_M438_Logatec.xml"
	F1 "M439" "M440" f_3000 "textileWiki/10/00278_M439_Luce.xml"
	F1 "M440" "M441" f_3000 "textileWiki/04/00357_M440_Mackovci.xml"
	F1 "M441" "M442" f_3000_1Cam "textileWiki/10/00432_M441_Metlika.xml"
	F1 "M442" "M443" f_3000 "textileWiki/10/00285_M442_Mezica.xml"
	F1 "M443" "M444" f_3000_1ComSrc_2Cam "textileWiki/18/00580_M443_Miklavz_na_Gorjancih.xml"
	F1 "M444" "M445" f_3000_2ComSrc_2Cam "textileWiki/14/00355_M444_Murska_Sobota.xml"
	F1 "M445" "M446" f_3000_2Cam "textileWiki/13/00142_M445_Nanos.xml"
	F1 "M446" "M447" f_3000 "textileWiki/11/00158_M446_Nova_vas_-_Bloke.xml"
	F1 "M447" "M448" f_3000_2ComSrc_1Cam "textileWiki/14/00249_M447_Novo_mesto.xml"
	F1 "M448" "M449" f_3000 "textileWiki/11/00176_M448_Osilnica.xml"
	F1 "M449" "M450" f_3000_1ComSrc_4Cam "textileWiki/08/00185_M449_Pasja_ravan.xml"
	F1 "M450" "M451" f_3000_2Cam "textileWiki/17/00815_M450_Pavlicevo_sedlo.xml"
	F1 "M451" "M452" f_3000 "textileWiki/02/00038_M451_Planina_pod_Golico.xml"
	F1 "M452" "M454" f_3000_1ComSrc_3Cam "textileWiki/11/00571_M452_Planina_v_Podbocju.xml"
#f_3000 "textileWiki/18/00835_M453_Vodice.xml"	
	F1 "M454" "M455" f_3000 "textileWiki/12/00816_M454_Podnanos.xml"
	F1 "M455" "M456" f_3000_1ComSrc_1Cam "textileWiki/14/00136_M455_Postojna.xml"
	F1 "M456" "M457" f_3000_2Cam "textileWiki/17/00052_M456_Predel.xml"
	F1 "M457" "M458" f_3000_1ComSrc_1Cam "textileWiki/14/00554_M457_Ptuj.xml"
	F1 "M458" "M459" f_3000_1ComSrc_3Cam "textileWiki/09/00817_M458_Ratitovec.xml"
	F1 "M459" "M460" f_3000_2Cam "textileWiki/13/00818_M459_Zgornja_Kapla.xml"
	F1 "M460" "M461" f_3000 "textileWiki/11/00821_M460_Ribnica_-_Dolenji_Lazi.xml"
	F1 "M461" "M462" f_3000 "textileWiki/10/00622_M461_Rogaska_Slatina.xml"
	F1 "M462" "M463" f_3000_2ComSrc_2Cam "textileWiki/16/00461_M462_Rogla.xml"
	F1 "M463" "M464" f_3000_2Cam "textileWiki/19/00553_M463_Rudno_Polje.xml"
	F1 "M464" "M465" f_3000 "textileWiki/13/00822_M464_Smarje_pri_Jelsah.xml"
	F1 "M465" "M466" f_3000 "textileWiki/10/00205_M465_Sevno.xml"
	F1 "M466" "M467" f_3000_1ComSrc_2Cam "textileWiki/16/00824_M466_Slavnik.xml"
	F1 "M467" "M468" f_3000 "textileWiki/13/00301_M467_Slovenske_Konjice.xml"
	F1 "M468" "M469" f_3000_1ComSrc_2Cam "textileWiki/16/00825_M468_Sveti_Trije_Kralji.xml"
	F1 "M469" "M470" f_3000 "textileWiki/13/00152_M469_Korosce.xml"
	F1 "M470" "M471" f_3000_1ComSrc_1Cam "textileWiki/14/00827_M470_Sviscaki.xml"
	F1 "M471" "M472" f_3000_2ComSrc_1Cam "textileWiki/14/00321_M471_Smartno_pri_Slovenj_Gradcu.xml"
	F1 "M472" "M473" f_3000 "textileWiki/11/00655_M472_Tatre.xml"
	F1 "M473" "M474" f_3000_1ComSrc_1Cam "textileWiki/11/00828_M473_Tolmin_-_Volce.xml"
	F1 "M474" "M475" f_3000 "textileWiki/16/00189_M474_Topol.xml"
	F1 "M475" "M476" f_3000 "textileWiki/10/00654_M475_Trebnje.xml"
	F1 "M476" "M477" f_3000_1ComSrc_1Cam "textileWiki/11/00829_M476_Trojane_-_Limovce.xml"
	F1 "M477" "M478" f_3000_3Cam "textileWiki/13/00289_M477_Urslja_gora.xml"
	F1 "M478" "M479" f_3000 "textileWiki/13/00092_M478_Vedrijan.xml"
	F1 "M479" "M480" f_3000 "textileWiki/06/00296_M479_Velenje.xml"
	F1 "M480" "M481" f_3000 "textileWiki/10/00813_M480_Velike_Lasce.xml"
	F1 "M481" "M482" f_3000_3Cam "textileWiki/18/00437_M481_Vogel.xml"
	F1 "M482" "M483" f_3000_2Cam "textileWiki/10/00075_M482_Sebreljski_vrh.xml"
	F1 "M483" "M484" f_3000_1Cam "textileWiki/16/00197_M483_Vrhnika.xml"
	F1 "M484" "M485" f_3000_2Cam "textileWiki/17/00830_M484_Vrsic.xml"
	F1 "M485" "M486" f_3000 "textileWiki/13/00710_M485_Zavodnje.xml"
	F1 "M486" "M487" f_3000_2Cam "textileWiki/17/00814_M486_Zelenica.xml"
	F1 "M487" "M488" f_3000 "textileWiki/11/00040_M487_Zgornja_Radovna.xml"
	F1 "M488" "M489" f_3000_1ComSrc_2Cam "textileWiki/02/00022_M488_Zgornja_Sorica.xml"
	F1 "M489" "M490" f_3000 "textileWiki/13/00510_M489_Jezersko.xml"
	F1 "M490" "M491" f_3000 "textileWiki/11/00020_M490_Ziri.xml"
#	F1 "M491" "M50" 
}

RUN_G(){
	F2 "G401" "/" f_230 "textileWiki/15/85069_G401_Ljubljana-Vojkova.xml"
	F2 "G402" "/" f_sp "textileWiki/06/70026_G402_Voglje.xml"
	F2 "G403" "/" f_sp "textileWiki/11/65005_G403_Podgorje.xml"
	F2 "G404" "/" f_sp "textileWiki/11/65036_G404_Menges.xml"
	F2 "G405" "/" f_sp "textileWiki/04/70011_G405_Sencur.xml"
	F2 "G406" "/" f_sp "textileWiki/04/73020_G406_Naklo.xml"
	F2 "G407" "/" f_sp "textileWiki/04/72020_G407_Radovljica.xml"
	F2 "G408" "/" f_sp "textileWiki/18/90076_G408_Iska_Loka.xml"
	F2 "G409" "/" f_sp "textileWiki/17/90016_G409_Bevke.xml"
	F2 "G410" "/" f_sp "textileWiki/07/30032_G410_Zalec.xml"
	F2 "G411" "/" f_sp "textileWiki/07/35046_G411_Latkova_vas.xml"
	F2 "G412" "/" f_sp "textileWiki/07/35029_G412_Trnava.xml"
	F2 "G413" "/" f_sp "textileWiki/15/50052_G413_Vihre.xml"
	F2 "G414" "/" f_sp "textileWiki/15/50013_G414_Zadovinek.xml"
	F2 "G415" "/" f_sp "textileWiki/15/50088_G415_Krska_Vas.xml"
	F2 "G416" "/" f_sp "textileWiki/12/20081_G416_Spodnja_Hajdina.xml"
	F2 "G417" "/" f_sp "textileWiki/12/20097_G417_Drazenci.xml"
	F2 "G418" "/" f_sp "textileWiki/12/15032_G418_Bukovci.xml"
	F2 "G419" "/" f_sp "textileWiki/12/15021_G419_Sobetinci.xml"
	F2 "G420" "/" f_sp "textileWiki/11/01092_G420_Gornji_Lakos.xml"
	F2 "G421" "/" f_sp "textileWiki/11/01037_G421_Gancani.xml"
	F2 "G422" "/" f_sp "textileWiki/06/80011_G422_Drulovka.xml"
	F2 "G423" "/" f_sp "textileWiki/04/71020_G423_Bled.xml"
	F2 "G424" "/" f_sp "textileWiki/11/65053_G424_Domzale.xml"
	F2 "G425" "/" f_sp "textileWiki/04/70035_G425_Trboje.xml"
	F2 "G426" "/" f_sp "textileWiki/04/70016_G426_Cerklje.xml"
	F2 "G427" "/" f_sp "textileWiki/12/17020_G427_Obrez.xml"
	F2 "G428" "/" f_sp "textileWiki/11/10068_G428_Mali_Segovci.xml"
	F2 "G429" "/" f_sp "textileWiki/04/80072_G429_Meja.xml"
	F2 "G430" "/" f_sp "textileWiki/11/01094_G430_Benica.xml"
	F2 "G431" "/" f_sp "textileWiki/07/35018_G431_Parizlje.xml"
	F2 "G432" "/" f_sp "textileWiki/17/90045_G432_Ljubljana-Rakova_Jelsa.xml"
	F2 "G433" "/" f_sp "textileWiki/19/70071_G433_Moste.xml"
	F2 "G434" "/" f_sp "textileWiki/19/80081_G434_Podreca.xml"
	F2 "G435" "/" f_sp "textileWiki/01/15011_G435_Dornava.xml"
	F2 "G436" "/" f_sp "textileWiki/01/20022_G436_Rogoza.xml"
	F2 "G437" "/" f_sp "textileWiki/01/20031_G437_Race.xml"
	F2 "G438" "/" f_sp "textileWiki/01/20033_G438_Starse.xml"
	F2 "G439" "/" f_sp "textileWiki/01/20041_G439_Brunsvik.xml"
	F2 "G440" "/" f_sp "textileWiki/01/20066_G440_Kungota.xml"
	F2 "G441" "/" f_230 "textileWiki/01/01052_G441_Rakican.xml"
	F2 "G442" "/" f_sp "textileWiki/01/01060_G442_Odranci.xml" ### 230V sa GSM!!
	F2 "G443" "/" f_sp "textileWiki/01/05051_G443_Zgornje_Krapje.xml" ### 230V sa GSM!!
	F2 "G444" "/" f_sp "textileWiki/01/05081_G444_Vescica.xml"
	F2 "G445" "/" f_sp "textileWiki/01/10022_G445_Zepovci.xml"
	F2 "G446" "/" f_sp "textileWiki/01/10036_G446_Crnci.xml"
}



RUN_H
RUN_M
#RUN_G





#for ((i=401; i<=446; i++))
#do
#	: 
#	#echo F1 \"M$i\" \"M$(($i+1))\"
#	echo F2 \"G$i\"
#done




	rm period.xml periodG.xml TARGET.xml temp.txt
	rm TEMP/TARGET*.xml 
echo ...........................................................................................................END
