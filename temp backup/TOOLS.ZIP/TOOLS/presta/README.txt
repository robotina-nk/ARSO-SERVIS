Zagon pregleda preste:
xober@deb60x:~/workspace-pivka-senzorji/3000.0.3/release-00008.0.3.1/TOOLS/presta$ ./runme.sh

Zagon pregleda omrezja:
xober@deb60x:~/workspace-pivka-senzorji/3000.0.3/release-00008.0.3.1/TOOLS/presta$ ./runmeIP.sh
xober@deb60x:~/workspace-pivka-senzorji/3000.0.3/release-00008.0.3.1/TOOLS/presta$ ./runmeIPCAT.sh




-------------------
./presta.sh presta.html
