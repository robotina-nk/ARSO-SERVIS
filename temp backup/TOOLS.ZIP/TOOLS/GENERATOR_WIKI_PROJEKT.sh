#!/bin/bash

if [ -f textile.xml ] ; then
    rm textile.xml
fi

source ./ROUTINES.cfg
source ./VARIABLES.cfg

	echo '<?xml version="1.0" encoding="UTF-8"?><wiki_page><title>Projekt</title><parent title="Wiki"/><text>!{width: 70%}http://pivka.arso.sigov.si/docs/xober_op_location/4000_aoberl/'$var_PIVKA_PATH'/900_foto/M493-JP-old.JPG!' >> textile.xml
	echo >> textile.xml
	echo "h1. Projektna dokumentacija" >> textile.xml
	echo >> textile.xml
	echo "h2. PZI dokumentacija" >> textile.xml
	echo >> textile.xml
	echo "p(. Izvlečki gradbenih PZI projektov, za potrebe montaže opreme na terenu." >> textile.xml
	echo "" >> textile.xml
	echo '* Dokument: "4000_MMKZ_Test_pzi":http://pivka.arso.sigov.si/docs/xober_op_location/4000_aoberl/'$var_PIVKA_PATH'/100_pzi' >> textile.xml
	echo "" >> textile.xml
	echo "h2. PID dokumentacija " >> textile.xml
	echo "" >> textile.xml
	echo "* Gradbena dela: " >> textile.xml
	echo '"PDF":http://pivka.arso.sigov.si/docs/xober_op_location/4000_aoberl/4000_MMKZ_Test/800_prevzemi/200_zagon_lokacija/201_pid-oprema/4000_MMKZ_Test_pid_gradbeni.pdf' >> textile.xml
	echo '"DWG":http://pivka.arso.sigov.si/docs/xober_op_location/4000_aoberl/4000_MMKZ_Test/800_prevzemi/200_zagon_lokacija/201_pid-oprema/4000_MMKZ_Test_pid_gradbeni.zip' >> textile.xml
	echo "" >> textile.xml
	echo "* Elektro-instalacijska dela:" >> textile.xml
	echo '"PDF":http://pivka.arso.sigov.si/docs/xober_op_location/4000_aoberl/4000_MMKZ_Test/800_prevzemi/200_zagon_lokacija/201_pid-oprema/4000_MMKZ_Test_pid.pdf' >> textile.xml
	echo "" >> textile.xml
	echo "" >> textile.xml
	echo "h2. Foto dokumentacija" >> textile.xml
	echo "" >> textile.xml
	echo "p((. - montaže merilnega sistema" >> textile.xml
	echo "- detaljev razdelilnih doz" >> textile.xml
	echo "- detaljev priključitve senzorjev na merilni sistem (detalj senzorskih priključitvenih portov)" >> textile.xml
	echo "" >> textile.xml
	echo '"Foto dokumentacija":http://pivka.arso.sigov.si/docs/xober_op_location/4000_aoberl/'$var_PIVKA_PATH'/900_foto/' >> textile.xml
	echo "" >> textile.xml
	echo "&amp;nbsp;" >> textile.xml
	echo "" >> textile.xml
	echo "----" >> textile.xml
	echo "" >> textile.xml
	echo "&amp;nbsp;" >> textile.xml
	echo "" >> textile.xml
	echo "h2. Popis opreme za ISMM." >> textile.xml
	echo "" >> textile.xml
	echo "" >> textile.xml
	echo '* Dokument: "ISMM_4000_MMKZ_Test.xls":http://pivka.arso.sigov.si/docs/xober_op_location/4000_aoberl/4000_MMKZ_Test/ISMM_4000_MMKZ_Test.xls' >> textile.xml
	echo "" >> textile.xml
	echo "" >> textile.xml
	echo "&amp;nbsp;" >> textile.xml
	echo "" >> textile.xml
	echo "----" >> textile.xml
	echo "" >> textile.xml
	echo "&amp;nbsp;" >> textile.xml
	echo "" >> textile.xml
	echo "h1. Prevzemna dokumentacija" >> textile.xml
	echo "" >> textile.xml
	echo "[[Prevzem]]" >> textile.xml
	echo "" >> textile.xml
	echo "* [[Prevzem#Testni zagon|Testni zagon]] - ustreznost delovanja opreme za montažo na lokaciji" >> textile.xml
	echo "" >> textile.xml
	echo "* [[Prevzem#Zagon lokacija|Zagon lokacija]] - ustreznost izvedbe merilne postaje na lokaciji" >> textile.xml
	echo '</text></wiki_page>' >> textile.xml
	#FIND_Projekt
		curl -v -u nkostic:Kosnik00 -H "Content-Type: application/xml" -X PUT http://pivka.arso.sigov.si/redmine/projects/$var_WIKI_PATH/wiki/Projekt.xml --data-binary "@textile.xml"
	cat textile.xml > DEL.xml
	rm textile.xml
