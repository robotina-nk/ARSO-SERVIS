#echo "TestCron" | mutt -s "Cron Test" nikola.kostic@robotina.com
cd /home/pi/ARSO
./RUN_FSCHK.sh
