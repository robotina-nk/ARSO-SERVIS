#!/bin/bash
./reportSEGMENTED.sh 1A &
./reportSEGMENTED.sh 1B &
./reportSEGMENTED.sh 2A &
./reportSEGMENTED.sh 2B &
./reportSEGMENTED.sh 3A &
./reportSEGMENTED.sh 3B &
./reportSEGMENTED.sh 4A &
./reportSEGMENTED.sh 4B &
./reportSEGMENTED.sh 5A &
./reportSEGMENTED.sh 5B &
./reportSEGMENTED.sh 6A &
./reportSEGMENTED.sh 6B &
./reportSEGMENTED.sh 7A &
./reportSEGMENTED.sh 7B &
./reportSEGMENTED.sh 8A &
./reportSEGMENTED.sh 8B &
