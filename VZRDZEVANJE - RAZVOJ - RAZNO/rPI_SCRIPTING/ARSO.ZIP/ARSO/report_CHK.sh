#!/bin/bash

# EXAMPLE

# ls /var/sda/ -R | grep err

# ls: /var/sda/amws/wmt702d/wmt702d.log.bak: Input/output error   KORPUTIRANI FAJLI

# ls: /var/sda/: No such file or directory   KARTICA NI VEČ MOUNTANA

# ssh: connect to host 172.19.139.146     #NEDOSEGLJIVA POSTAJA
# port 22: Connection timed out




DO_FIND(){
	echo
	echo $1
	var_IP1=$(cat $1 | grep IP1 | sed 's/|_&lt;.IP1|//g' | sed 's/||_&lt;.IP radius server||//g')
	echo $var_IP1
	#sshpass -p "rebox" ssh -o StrictHostKeyChecking=no root@$var_IP1 'ls /var/sda/ -R | grep init.log'
	sshpass -p "rebox" ssh -o StrictHostKeyChecking=no root@$var_IP1 'ls /var/sda/ -R | grep err'
	echo "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -"
}



DO_FIND "textileWiki/00311_M023_Maribor_Letalisce_ER.xml"

DO_FIND "textileWiki/10/00164_M401_Babno_Polje.xml"
DO_FIND "textileWiki/06/00097_M402_Bilje.xml"
DO_FIND "textileWiki/17/00819_M403_Blegos.xml"
DO_FIND "textileWiki/11/00482_M404_Bohinjska_Cesnjica.xml"
DO_FIND "textileWiki/11/00061_M405_Breginj.xml"
DO_FIND "textileWiki/10/00812_M406_Bukovski_vrh.xml"
DO_FIND "textileWiki/10/00831_M407_Cerknisko_jezero.xml"
DO_FIND "textileWiki/02/00832_M408_Zadlog.xml"
DO_FIND "textileWiki/04/00021_M409_Davca.xml"	
DO_FIND "textileWiki/16/00826_M410_Marinca_vas.xml"
DO_FIND "textileWiki/06/00555_M411_Gacnik.xml"
DO_FIND "textileWiki/11/00107_M412_Godnje.xml"
DO_FIND "textileWiki/10/00275_M413_Radegunda.xml"	
DO_FIND "textileWiki/10/00276_M414_Gornji_Grad.xml"
DO_FIND "textileWiki/04/00653_M415_Hocko_Pohorje.xml"
DO_FIND "textileWiki/19/00559_M416_Idrija.xml"
#DO_FIND "textileWiki/02/00498_M417_Iskrba.xml"
  DO_FIND "textileWiki/00498_M417_Iskrba.xml"
DO_FIND "textileWiki/18/00030_M418_Jelendol.xml"
DO_FIND "textileWiki/06/00272_M419_Jeronim.xml"
DO_FIND "textileWiki/10/00348_M420_Jeruzalem.xml"
DO_FIND "textileWiki/16/00133_M421_Jursce.xml"
DO_FIND "textileWiki/04/00339_M422_Kadrenci.xml"
DO_FIND "textileWiki/13/00820_M423_Kamniska_Bistrica.xml"
DO_FIND "textileWiki/09/00436_M424_Kanin.xml"
DO_FIND "textileWiki/04/00068_M425_Kneske_ravne.xml"
DO_FIND "textileWiki/10/00174_M426_Kocevje.xml"
DO_FIND "textileWiki/11/00251_M427_Kocevske_Poljane.xml"
DO_FIND "textileWiki/18/00823_M428_Korensko_sedlo.xml"
DO_FIND "textileWiki/02/00656_M429_Kranj.xml"
DO_FIND "textileWiki/10/00048_M430_Kredarica.xml"
DO_FIND "textileWiki/10/00065_M431_Krn.xml"
DO_FIND "textileWiki/16/00003_M432_Krvavec.xml"
DO_FIND "textileWiki/13/00121_M433_Kubed.xml"
DO_FIND "textileWiki/18/00210_M434_Kum.xml"
DO_FIND "textileWiki/18/00452_M435_Lisca.xml"
DO_FIND "textileWiki/09/00206_M436_Litija.xml"
DO_FIND "textileWiki/10/00280_M437_Logarska_dolina.xml"
DO_FIND "textileWiki/02/00147_M438_Logatec.xml"
DO_FIND "textileWiki/10/00278_M439_Luce.xml"
DO_FIND "textileWiki/04/00357_M440_Mackovci.xml"
DO_FIND "textileWiki/10/00432_M441_Metlika.xml"
DO_FIND "textileWiki/10/00285_M442_Mezica.xml"
DO_FIND "textileWiki/18/00580_M443_Miklavz_na_Gorjancih.xml"
DO_FIND "textileWiki/14/00355_M444_Murska_Sobota.xml"
DO_FIND "textileWiki/13/00142_M445_Nanos.xml"
DO_FIND "textileWiki/11/00158_M446_Nova_vas_-_Bloke.xml"
DO_FIND "textileWiki/14/00249_M447_Novo_mesto.xml"	
DO_FIND "textileWiki/11/00176_M448_Osilnica.xml"
DO_FIND "textileWiki/08/00185_M449_Pasja_ravan.xml"
DO_FIND "textileWiki/17/00815_M450_Pavlicevo_sedlo.xml"
DO_FIND "textileWiki/02/00038_M451_Planina_pod_Golico.xml"
DO_FIND "textileWiki/11/00571_M452_Planina_v_Podbocju.xml"
#f_3000 "textileWiki/18/00835_M453_Vodice.xml"	
DO_FIND "textileWiki/12/00816_M454_Podnanos.xml"
DO_FIND "textileWiki/14/00136_M455_Postojna.xml"
DO_FIND "textileWiki/17/00052_M456_Predel.xml"
DO_FIND "textileWiki/14/00554_M457_Ptuj.xml"
DO_FIND "textileWiki/09/00817_M458_Ratitovec.xml"
DO_FIND "textileWiki/13/00818_M459_Zgornja_Kapla.xml"
DO_FIND "textileWiki/11/00821_M460_Ribnica_-_Dolenji_Lazi.xml"
DO_FIND "textileWiki/10/00622_M461_Rogaska_Slatina.xml"
DO_FIND "textileWiki/16/00461_M462_Rogla.xml"
DO_FIND "textileWiki/19/00553_M463_Rudno_Polje.xml"
DO_FIND "textileWiki/13/00822_M464_Smarje_pri_Jelsah.xml"
DO_FIND "textileWiki/10/00205_M465_Sevno.xml"
DO_FIND "textileWiki/16/00824_M466_Slavnik.xml"
DO_FIND "textileWiki/13/00301_M467_Slovenske_Konjice.xml"
DO_FIND "textileWiki/16/00825_M468_Sveti_Trije_Kralji.xml"
DO_FIND "textileWiki/13/00152_M469_Korosce.xml"
DO_FIND "textileWiki/14/00827_M470_Sviscaki.xml"
DO_FIND "textileWiki/14/00321_M471_Smartno_pri_Slovenj_Gradcu.xml"
DO_FIND "textileWiki/11/00655_M472_Tatre.xml"
DO_FIND "textileWiki/11/00828_M473_Tolmin_-_Volce.xml"
DO_FIND "textileWiki/16/00189_M474_Topol.xml"
DO_FIND "textileWiki/10/00654_M475_Trebnje.xml"
DO_FIND "textileWiki/11/00829_M476_Trojane_-_Limovce.xml"
DO_FIND "textileWiki/13/00289_M477_Urslja_gora.xml"
DO_FIND "textileWiki/13/00092_M478_Vedrijan.xml"
DO_FIND "textileWiki/06/00296_M479_Velenje.xml"
DO_FIND "textileWiki/10/00813_M480_Velike_Lasce.xml"
DO_FIND "textileWiki/18/00437_M481_Vogel.xml"
DO_FIND "textileWiki/10/00075_M482_Sebreljski_vrh.xml"
DO_FIND "textileWiki/16/00197_M483_Vrhnika.xml"
DO_FIND "textileWiki/17/00830_M484_Vrsic.xml"	
DO_FIND "textileWiki/13/00710_M485_Zavodnje.xml"
DO_FIND "textileWiki/17/00814_M486_Zelenica.xml"
DO_FIND "textileWiki/11/00040_M487_Zgornja_Radovna.xml"
DO_FIND "textileWiki/02/00022_M488_Zgornja_Sorica.xml"
DO_FIND "textileWiki/13/00510_M489_Jezersko.xml"
DO_FIND "textileWiki/11/00020_M490_Ziri.xml"
#	F1 "M491" "M50" 





