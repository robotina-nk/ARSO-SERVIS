#!/bin/bash
d=`date -d '+0 hour' +%y%m%d%H%M%S`

#dan=`date -d '+0 hour' +%d`
#mesec=`date -d '+0 hour' +%m`
#leto=`date -d '+0 hour' +%y`
#ura=`date -d '+0 hour' +%H`
#minuta=`date -d '+0 hour' +%M`
#datum="$dan"."$mesec"."$leto $ura":"$minuta"

#cd /home/pi/ARSO
./report_CHK.sh |& tee FSCHK_$d.txt
#echo "FSCHK pregled $d" | mutt -s "FSCHK $d" nikola.kostic@robotina.com -a FSCHK_$d.txt
echo "FSCHK pregled $d" | mutt -s "FSCHK $d" nikola.kostic@robotina.com marko.mlakar@robotina.com -a FSCHK_$d.txt
sshpass -p "Kosnik00" rsync -avz FSCHK_$d.txt nkostic@pivka.arso.sigov.si:/opt1/arso/docs/xober_op_location/0000_xoberl/000_korespondenca/Pregled_Presta_NetScan

#rm IP_SCAN_$d.html
rm FSCHK_$d.txt
