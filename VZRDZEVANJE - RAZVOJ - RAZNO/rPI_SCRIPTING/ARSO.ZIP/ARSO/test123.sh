#echo "TestCron" | mutt -s "Cron Test" nikola.kostic@robotina.com
#cd /home/pi/ARSO
#./RUN_IP.sh
#sshpass -p "rebox" ssh -o StrictHostKeyChecking=no root@$var_IP1 'ls /var/sda/ -R | grep err'
echo "" > testPHP.txt
while true
do 
    #echo "Hi"
    sshpass -p "rebox" ssh -o StrictHostKeyChecking=no xober@172.19.6.126 'date' >> testPHP.txt
    sshpass -p "rebox" ssh -o StrictHostKeyChecking=no xober@172.19.6.126 'ps -e | grep php' >> testPHP.txt
    echo "============================================================================" >> testPHP.txt
    sleep 10
done
