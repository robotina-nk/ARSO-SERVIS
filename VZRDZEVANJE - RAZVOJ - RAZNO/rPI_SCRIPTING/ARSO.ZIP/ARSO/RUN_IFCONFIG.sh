#!/bin/bash

#ifconfig | grep "inet 172."

