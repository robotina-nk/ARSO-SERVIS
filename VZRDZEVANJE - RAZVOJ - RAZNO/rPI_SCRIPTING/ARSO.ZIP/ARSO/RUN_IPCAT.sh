#!/bin/bash
d=`date -d '+0 hour' +%y%m%d%H%M%S`
#rm ./ende.html
cat TPLreportSTART.html resultreport_1A.htm resultreport_1B.htm resultreport_2A.htm resultreport_2B.htm resultreport_3A.htm resultreport_3B.htm resultreport_4A.htm resultreport_4B.htm resultreport_5A.htm resultreport_5B.htm resultreport_6A.htm resultreport_6B.htm resultreport_7A.htm resultreport_7B.htm resultreport_8A.htm resultreport_8B.htm > IP_SCAN_$d.html
rm ./resultreport_*.htm
rm ./pinglog*.txt

dan=`date -d '+0 hour' +%d`
mesec=`date -d '+0 hour' +%m`
leto=`date -d '+0 hour' +%y`
ura=`date -d '+0 hour' +%H`
minuta=`date -d '+0 hour' +%M`
datum="$dan"."$mesec"."$leto $ura":"$minuta"

sed -i "s/<td>.<td><td><td>/<td>$datum<td><td><td>/g" IP_SCAN_$d.html 

#echo "Presta pregled $d" | mutt -s "presta $d" nikola.kostic@robotina.com marko.mlakar@robotina.com -a IP_SCAN_$d.html
echo "Presta pregled $d" | mutt -s "presta $d" nikola.kostic@robotina.com -a IP_SCAN_$d.html

sshpass -p "Kosnik00" rsync -avz IP_SCAN_$d.html nkostic@pivka.arso.sigov.si:/opt1/arso/docs/xober_op_location/0000_xoberl/000_korespondenca/Pregled_Presta_NetScan
rm IP_SCAN_$d.html
